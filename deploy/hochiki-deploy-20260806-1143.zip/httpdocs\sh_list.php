<?php
define('SH_LIST_SLOT_AKI', 'aki');
define('SH_LIST_SLOT_WAKUOVER', 'wakuover');

$isAdminMode = TRUE;
include_once "C:/xampp/htdocs/hochiki/SPFW/inc/setting.properties";
	include_once _INC_DIR . "carrier.inc";
	include_once _INC_DIR . "global.inc";

	include_once _CLS_DIR . "SPFWDatabase.cls";
	include_once _CLS_DIR . "SPFWLog.cls";
	include_once _CLS_DIR . "SPFWTemplate.cls";
	include_once _CLS_DIR . "SPFWListObject.cls";
	include_once _CLS_DIR . "SPFWParameter.cls";
#	include_once _CLS_DIR . "SPFWDate.cls";
	include_once _CLS_DIR . "SPFWInputCheck.cls";
	include_once _CLS_DIR . "SPUSUser.cls";
	include_once _CLS_DIR . "SPUSReservation.cls";
	include_once _CLS_DIR . "SPUSBukken.cls";
	// include_once _CLS_DIR . "SPUSHenkoRoom.cls";
	// include_once _CLS_DIR . "SPUSHenkoDate.cls";
include_once _CLS_DIR . "SPUSBuilding.cls";
include_once __DIR__ . "/include/bukken_alert.php";
include_once __DIR__ . "/include/sh_list_slot_helpers.php";
include_once __DIR__ . "/include/building_period_helpers.php";
include_once __DIR__ . "/include/holiday_helpers.php";



	// データベースコネクト
 	$myDB = new SPFWDatabase(_MAIN_DB, _HOST_NAME, _USER_NAME, _PASSWD, FALSE);
	if (!$myDB->Connection)
		trigger_error("SPFWDatabase Failed.", E_USER_ERROR);



	########################################################
	# 値取得
	########################################################
	$rKey 			= SPFWParameter::getValues("rKey");
	$editBukkenCD = SPFWParameter::getValues('editBukkenCD');
	$editBuildingCD = SPFWParameter::getValues('editBuildingCD');
	$ClientCD = SPFWParameter::getValues('ClientCD');
	$work = SPFWParameter::getValues('work');
	$m 				= SPFWParameter::getValues('m');
	$menu = SPFWParameter::getValues('menu'); // If this page is navigated using menu click
	$Biko = SPFWParameter::getValues('Biko');
	$bikoreg = SPFWParameter::getValues('bikoreg');


	########################################################
	# 認証動作
	########################################################
	if ($rKey) {

		$myUser = new User($myDB);
		if ($rKey == NULL)
			showSorryPage(_ILLEGAL_ACCESS2);

		if (!$myUser->doAuthenticationByRegistKey($rKey))
			trigger_error("doAuthentication Failed.", E_USER_ERROR);

		if ($myUser->UserCD == -1)
			showSorryPage(_ILLEGAL_ACCESS2);

			$myUserCD 		= $myUser->UserCD;
			$ClientCD 		= $myUser->ClientCD;
			$UserKbn 		= $myUser->UserKbn;
			unset($myUser);
	}

	$IfWorker = $UserKbn == 3;
	$IfDeveloper	= $UserKbn != 3;
	$IfSP 			= $m == 1; // スマホ用
	$IfPC 			= $m != 1;
	$IfShowSchedule = false;
	if($IfSP){
		if($IfDeveloper)
			$IfShowSchedule = true;
		$IfWorker		= true;
		$IfDeveloper	= false;
	}

// if ($UserKbn == 3) {
// 	$SHeaderKanri = "<div style='text-align:center;'>";
// 	$SHeaderKanri .= "<img class='logo'  src='./images/489work.png' alt='489作業者' width='600' height='73'>";
// 	$SHeaderKanri .= "</div>";
// }

$myBukken = new Bukken($myDB);
if (!$myBukken->executeSelect(" BukkenCD = '".$editBukkenCD."' AND MukouFlg = FALSE", "")) {
	$ErrorString = array();
	$ErrorString[] = "設定ファイル情報の抽出に失敗しました。";
	$ErrorLoop = count($ErrorString);
	$myTemplate = new SPFWTemplate(_ADMIN_ERROR_TPL, $MyCarrier, TRUE);
	unset($myTemplate);
	exit;
}

// 棟一覧
function numberToCircled($number) {
    $map = [
        1 => '①', 2 => '②', 3 => '③', 4 => '④', 5 => '⑤',
        6 => '⑥', 7 => '⑦', 8 => '⑧', 9 => '⑨', 10 => '⑩',
        11 => '⑪', 12 => '⑫', 13 => '⑬', 14 => '⑭', 15 => '⑮',
        16 => '⑯', 17 => '⑰', 18 => '⑱', 19 => '⑲', 20 => '⑳'
    ];

    return $map[$number] ?? $number;
}
$myListObject = new SPFWListObject($myDB);

$sql = "SELECT ";
$sql .= "u.BuildingCD, ";
$sql .= "u.BuildingName ";

$myListObject->SelectSQL = $sql;

$sql = " FROM tBuildingM u ";
$sql .= " WHERE u.MukouFlg = FALSE AND BukkenCD='".$editBukkenCD."'";

$myListObject->Condition = $sql;
$myListObject->Order = "u.BuildingCD ASC";
$myListObject->Limit = "allpage";

if (!($myListObject->GetList(1)))
	trigger_error("Getting User List Failed.", E_USER_ERROR);

$BuildingCD = [];
$BuildingName = [];
$naviClass = [];
$mainNaviClass = 'active';
$BuildingLoop = $myListObject->Rows;

// 基本棟のデータが存在しない場合、データが存在している棟を選択します。
if($menu == '1'){
	$wWakuPattern = $myBukken->WakuPattern;
	if($wWakuPattern == ""){
		for ($i = 0; $i < $BuildingLoop; $i++) {
			$BuildingCD[$i] = $myListObject->GetValue($i, 0);
			$tempBuilding = new Building($myDB);
			if($BuildingCD[$i]){
				if ($tempBuilding->executeSelect("BukkenCD = " . $editBukkenCD . " AND BuildingCD = ".$BuildingCD[$i]." AND MukouFlg = FALSE", "") || $tempBuilding->RecCnt != 1) {
					if($tempBuilding && $tempBuilding->WakuPattern){
						$editBuildingCD = $BuildingCD[$i];
						break;
					}
				}
			}

		}
	}
}

for ($i = 0; $i < $BuildingLoop; $i++) {
	$BuildingCD[$i] = $myListObject->GetValue($i, 0);
	$BuildingName[$i] = $myListObject->GetValue($i, 1);
	if(!$BuildingName[$i])
		$BuildingName[$i] = '棟'.numberToCircled($i+2);

	if($BuildingCD[$i] == $editBuildingCD){
		$naviClass[$i] = 'active';
		$mainNaviClass = '';
	}
	else{
		$naviClass[$i] = '';
	}

}
unset($myListObject);

#######################################移植
	########################################################
# クライアント取得 tBukkenMからとる
########################################################

$myBuilding = new Building($myDB);
if($editBuildingCD){
	if (!$myBuilding->executeSelect("BukkenCD = " . $editBukkenCD . " AND BuildingCD = ".$editBuildingCD." AND MukouFlg = FALSE", "") || $myBuilding->RecCnt != 1) {
		$ErrorString = array();
		$ErrorString[] = "設定ファイル情報の抽出に失敗しました。";
		$ErrorLoop = count($ErrorString);
		$myTemplate = new SPFWTemplate(_ADMIN_ERROR_TPL, $MyCarrier, TRUE);
		unset($myTemplate);
		exit;
	}
}

$MansionName = $myBukken->BukkenName;
$wBuildingName = $myBukken->BuildingName;
if(!$wBuildingName){
	if($BuildingLoop > 0){
		$wBuildingName = '棟'.numberToCircled(1);
	}
}
if($BuildingLoop > 0)
	$IfBuildingExist = true;
else
	$IfBuildingExist = false;


$wWakuPattern = $myBukken->WakuPattern;
$MaxWakuSu = $myBukken->MaxWakuSu;#6-4-4
$wHansu = $myBukken->Hansu;
$SyonitiKouryo = $myBukken->FirstDateFeature; 
$Holiday1 = $myBukken->Holiday1;
$ReserveDay = $myBukken->ReserveDay;
$wFirstDateFeature = $myBukken->FirstDateFeature;
$wFrameOverflow = $myBukken->FrameOverflow;
$wArrangeType = $myBukken->ArrangeType;
$wFloorReserveInfo = $myBukken->FloorReserveInfo;

if($bikoreg == "yes"){
	$work = '';
	$myBukken->Biko =$Biko;
	if (!$myBukken->executeUpdate())
		trigger_error("Updating myBukken Failed.", E_USER_ERROR);
}


$wBiko = $myBukken->Biko;

if($editBuildingCD){
	$wWakuPattern = $myBuilding->WakuPattern;
	$MaxWakuSu = $myBuilding->MaxWakuSu;#6-4-4
	$wHansu = $myBuilding->Hansu;
	$SyonitiKouryo = $myBuilding->FirstDateFeature; 
	$Holiday1 = $myBuilding->Holiday1;
	$ReserveDay = $myBuilding->ReserveDay;
	$wFirstDateFeature = $myBuilding->FirstDateFeature;
	$wFrameOverflow = $myBuilding->FrameOverflow;
	$wArrangeType = $myBuilding->ArrangeType;
	$wFloorReserveInfo = $myBuilding->FloorReserveInfo;
}
if($wArrangeType == '1'){
	$wFloorReserveInfo = html_entity_decode($wFloorReserveInfo, ENT_QUOTES, 'UTF-8');
	$arrFloorReserveInfo = json_decode($wFloorReserveInfo, true);
}

// 【2026/06 Option B】点検物件も工事と同様に「容量（バンド）のみ」で空き/枠越を判定し、
// フロア紐付け（FloorReserveInfo / tReservationInitF）による枠越判定は行わない。
// 元の挙動に戻す場合は true にする。
if(!defined('RESERVE_USE_FLOOR_BINDING')) define('RESERVE_USE_FLOOR_BINDING', false);

$MaxWaku = explode("-",$MaxWakuSu);
$wWakuAM = $MaxWaku[0];
$wWakuPM = $MaxWaku[1];
$wWakuPM1 = $MaxWaku[1];
if(count($MaxWaku)>2){
	$wWakuPM2 = $MaxWaku[2];
}
$TargetClientCD = $myBukken->ClientCD;#111
$resolvedPeriod = resolveBuildingSenyuAndYoyaku($myBukken, $editBuildingCD ? $myBuilding : null, $editBuildingCD);
$SenyuStartDate = $resolvedPeriod['SenyuStartDate'];
$SenyuEndDate = $resolvedPeriod['SenyuEndDate'];
$YoyakuEndDate = $resolvedPeriod['YoyakuEndDate'];

$SenyuDateCnt = ((strtotime($SenyuEndDate) -  strtotime($SenyuStartDate)) / 86400) + 1; #専有部日数
$MinuteTime = $myBukken->MinuteTime; #20ぷん
$wHolidayItems = parseHoliday1($Holiday1);
$wHoliday = array();
foreach ($wHolidayItems as $hi) {
	$wHoliday[] = $hi['date'];
}
sort($wHoliday);

$wReserveDay = SPFWTools::decodePluralValue($ReserveDay);
sort($wReserveDay);

$beforeReserveDay = [];
$afterReserveDay = [];
foreach($wReserveDay as $aReserveDay){
	$dateReserveDay = new DateTime($aReserveDay);
	$dateSenyuStartDate = new DateTime($SenyuStartDate);
	$dateSenyuEndDate = new DateTime($SenyuEndDate);

	if($dateReserveDay < $dateSenyuStartDate){
		array_push($beforeReserveDay, $aReserveDay);
	}else if($dateReserveDay > $dateSenyuEndDate){
		array_push($afterReserveDay, $aReserveDay);
	}
}

$MaxWaku = explode("-",$MaxWakuSu);
$wWakuAM = $MaxWaku[0];
$wWakuPM = $MaxWaku[1];
$wWakuPM1 = $MaxWaku[1];
if(count($MaxWaku)>2){
	$wWakuPM2 = $MaxWaku[2];
}

unset($myBukken);

if($work){ // 情報登録=1, 確定=2, 変更=3
	$aHenkoDate = SPFWParameter::getValues('HenkoDate');#wHenkoDateにしたら下でダブっておかしくなる
	$aTimeFromTime = SPFWParameter::getValues('TimeFromTime');
	$aHanNo = SPFWParameter::getValues('HanNo');
	$aViewOrderNo = SPFWParameter::getValues('ViewOrderNo');
	$aBlankSlotType = SPFWParameter::getValues('BlankSlotType');
	$aRoomNo = SPFWParameter::getValues('RoomNo');
	$aLastName = SPFWParameter::getValues('Name');
	$aTEL = SPFWParameter::getValues('TEL');
	$aEMail = SPFWParameter::getValues('EMail');
	$aMemo = SPFWParameter::getValues('Memo');
	$TimeExactHour = SPFWParameter::getValues('TimeExactHour');
	$TimeExactMinutes = SPFWParameter::getValues('TimeExactMinutes');
	if($TimeExactHour || $TimeExactMinutes)
		$aTimeExact = $TimeExactHour.":".$TimeExactMinutes;
	else
		$aTimeExact = "";
	$aTimeMeaning = SPFWParameter::getValues('TimeMeaning');
	###登録処理
	if($aHenkoDate != 'red'){#Javascriptに　HiddenHenkoDate の　ElementByID部分の変更前の値

		$myReservation = new Reservation($myDB);

		if($editBuildingCD){
			if (!$myReservation->executeSelect("  BukkenCD = '".$editBukkenCD."' AND BuildingCD = '".$editBuildingCD."' AND ID = $aRoomNo AND MukouFlg = FALSE", "")) 
				trigger_error("Getting Reservation Failed.", E_USER_ERROR);
		}else{
			if (!$myReservation->executeSelect("  BukkenCD = '".$editBukkenCD."' AND BuildingCD IS NULL AND ID = $aRoomNo AND MukouFlg = FALSE", "")) 
				trigger_error("Getting Reservation Failed.", E_USER_ERROR);
		}
		
		if($work == '1'){ // 情報登録 = 確定
			$myUser = new User($myDB);
			if($editBuildingCD){
				if (!$myUser->executeSelect("  BukkenCD = '".$editBukkenCD."' AND BuildingCD = '".$editBuildingCD."' AND ID = '".$aRoomNo."' AND MukouFlg = FALSE", "")) 
					trigger_error("Getting Reservation Failed.", E_USER_ERROR);
			}else{
				if (!$myUser->executeSelect("  BukkenCD = '".$editBukkenCD."' AND BuildingCD IS NULL AND ID = '".$aRoomNo."' AND MukouFlg = FALSE", "")) 
					trigger_error("Getting Reservation Failed.", E_USER_ERROR);
			}
			if($aHenkoDate && $aTimeFromTime){
				$myReservation->TimeFrom = $aHenkoDate." ".$aTimeFromTime;
				// $MinuteTime（20分）後の時刻を計算
				$TimeToTime = date('H:i', strtotime('+'.$MinuteTime.' minutes', strtotime($TimeFromTime)));
				$myReservation->TimeTo = $aHenkoDate." ".$TimeToTime;
			}
			// if($myUser->ReplyFlg == '3'){
			// 	$myReservation->Memo = NULL;
			// 	$myReservation->TimeExact = NULL;
			// 	$myReservation->TimeMeaning = NULL;
			// }else{
			// 	$myReservation->Memo = $aMemo;
			// 	$myReservation->TimeExact = $aTimeExact;
			// 	$myReservation->TimeMeaning = $aTimeMeaning;
			// 	$myUser->ReplyFlg 	= "2";#TEL受付
			// }
			$myReservation->Memo = $aMemo;
			$myReservation->TimeExact = $aTimeExact;
			$myReservation->TimeMeaning = $aTimeMeaning;
			$myUser->ReplyFlg 	= "1";
			$myUser->ConfirmFlg = "1";

			if($aHanNo){
				$myReservation->HanNo = $aHanNo;
			}
			if($aViewOrderNo){
				$myReservation->ViewOrderNo = $aViewOrderNo;
			}
			shListApplyBlankSlotTypeToReservation($myReservation, $aBlankSlotType);
			$myReservation->Updater = $myUserCD;
			$myReservation->Updated = "NOW()";

			$myUser->Updater = $myUserCD;
			$myUser->LastName = $aLastName;
			$myUser->TEL 	=  $aTEL;
			$myUser->EMail 	=  $aEMail;
			if (!$myUser->executeUpdate())
				trigger_error("Updating myUser Failed.", E_USER_ERROR);

			if (!$myReservation->executeUpdate())
				trigger_error("Updating myReservation Failed.", E_USER_ERROR);

			recordBukkenTelActivity($myDB, $editBukkenCD);#TEL受付更新を協力会社へ通知

	// // 		####登録処理End
	// // 		####変数ドロップしておく。
			SPFWTemplate::dropValue('work');
			// リダイレクトによるページリロード
			header("Location: " . $_SERVER['PHP_SELF'] . "?ClientCD=" . urlencode($ClientCD)."&editBukkenCD=" . urlencode($editBukkenCD)."&editBuildingCD=" . urlencode($editBuildingCD)."&rKey=" . urlencode($rKey));
			exit;
		}else if($work == '2'){ // 確定
			$myUser = new User($myDB);
			if($editBuildingCD){
				if (!$myUser->executeSelect("  BukkenCD = '".$editBukkenCD."' AND BuildingCD = '".$editBuildingCD."' AND ID = '".$aRoomNo."' AND MukouFlg = FALSE", "")) 
					trigger_error("Getting Reservation Failed.", E_USER_ERROR);
			}else{
				if (!$myUser->executeSelect("  BukkenCD = '".$editBukkenCD."' AND BuildingCD IS NULL AND ID = '".$aRoomNo."' AND MukouFlg = FALSE", "")) 
					trigger_error("Getting Reservation Failed.", E_USER_ERROR);
			}
			$myUser->Updater = $myUserCD;
			$myUser->ReplyFlg 	= "1";
			$myUser->ConfirmFlg = "1";
			if (!$myUser->executeUpdate())
				trigger_error("Updating myUser Failed.", E_USER_ERROR);
			recordBukkenTelActivity($myDB, $editBukkenCD);#TEL受付更新を協力会社へ通知
			SPFWTemplate::dropValue('work');
		}else if($work == '3'){ // 変更
			if($aHenkoDate && $aTimeFromTime){
				$myReservation->TimeFrom = $aHenkoDate." ".$aTimeFromTime;
				// $MinuteTime（20分）後の時刻を計算
				$TimeToTime = date('H:i', strtotime('+'.$MinuteTime.' minutes', strtotime($TimeFromTime)));
				$myReservation->TimeTo = $aHenkoDate." ".$TimeToTime;
			}
			$myReservation->Memo = $aMemo;
			$myReservation->TimeExact = $aTimeExact;
			$myReservation->TimeMeaning = $aTimeMeaning;
			$myReservation->HanNo = $aHanNo;
			$myReservation->ViewOrderNo = $aViewOrderNo;
			shListApplyBlankSlotTypeToReservation($myReservation, $aBlankSlotType);
			$myReservation->Updater = $myUserCD;
			$myReservation->Updated = "NOW()";

			if (!$myReservation->executeUpdate())
				trigger_error("Updating myReservation Failed.", E_USER_ERROR);

			$myUser = new User($myDB);
			if($editBuildingCD){
				if (!$myUser->executeSelect("  BukkenCD = '".$editBukkenCD."' AND BuildingCD = '".$editBuildingCD."' AND ID = '".$aRoomNo."' AND MukouFlg = FALSE", "")) 
					trigger_error("Getting Reservation Failed.", E_USER_ERROR);
			}else{
				if (!$myUser->executeSelect("  BukkenCD = '".$editBukkenCD."' AND BuildingCD IS NULL AND ID = '".$aRoomNo."' AND MukouFlg = FALSE", "")) 
					trigger_error("Getting Reservation Failed.", E_USER_ERROR);
			}

			$myUser->Updater = $myUserCD;
			$myUser->LastName = $aLastName;
			$myUser->TEL 	=  $aTEL;
			$myUser->EMail 	=  $aEMail;
			$myUser->ReplyFlg 	= "1";
			$myUser->ConfirmFlg = "1";
			if (!$myUser->executeUpdate())
				trigger_error("Updating myUser Failed.", E_USER_ERROR);
			recordBukkenTelActivity($myDB, $editBukkenCD);#TEL受付更新を協力会社へ通知
			SPFWTemplate::dropValue('work');
		}else if($work == '4'){ // 辞退
			$myReservation->TimeExact = NULL;
			$myReservation->TimeMeaning = NULL;
			$myReservation->Updated = "NOW()";
			if (!$myReservation->executeUpdate())
				trigger_error("Updating myReservation Failed.", E_USER_ERROR);

			$myUser = new User($myDB);
			if($editBuildingCD){
				if (!$myUser->executeSelect("  BukkenCD = '".$editBukkenCD."' AND BuildingCD = '".$editBuildingCD."' AND ID = '".$aRoomNo."' AND MukouFlg = FALSE", "")) 
					trigger_error("Getting Reservation Failed.", E_USER_ERROR);
			}else{
				if (!$myUser->executeSelect("  BukkenCD = '".$editBukkenCD."' AND BuildingCD IS NULL AND ID = '".$aRoomNo."' AND MukouFlg = FALSE", "")) 
					trigger_error("Getting Reservation Failed.", E_USER_ERROR);
			}
			$myUser->Updater = $myUserCD;
			$myUser->ReplyFlg 	= "3";

			if (!$myUser->executeUpdate())
				trigger_error("Updating myUser Failed.", E_USER_ERROR);
			recordBukkenTelActivity($myDB, $editBukkenCD);#TEL受付更新を協力会社へ通知
			SPFWTemplate::dropValue('work');
		}else if($work == '5'){ // 復活
			$myReservation->TimeFrom = $aHenkoDate." ".$aTimeFromTime;
			// $MinuteTime（20分）後の時刻を計算
			$TimeToTime = date('H:i', strtotime('+'.$MinuteTime.' minutes', strtotime($TimeFromTime)));
			$myReservation->TimeTo = $aHenkoDate." ".$TimeToTime;
			$myReservation->HanNo = $aHanNo;
			$myReservation->ViewOrderNo = $aViewOrderNo;
			$myReservation->Updater = $myUserCD;
			$myReservation->Updated = "NOW()";

			if (!$myReservation->executeUpdate())
				trigger_error("Updating myReservation Failed.", E_USER_ERROR);

			$myUser = new User($myDB);
			if($editBuildingCD){
				if (!$myUser->executeSelect("  BukkenCD = '".$editBukkenCD."' AND BuildingCD = '".$editBuildingCD."' AND ID = '".$aRoomNo."' AND MukouFlg = FALSE", "")) 
					trigger_error("Getting Reservation Failed.", E_USER_ERROR);
			}else{
				if (!$myUser->executeSelect("  BukkenCD = '".$editBukkenCD."' AND BuildingCD IS NULL AND ID = '".$aRoomNo."' AND MukouFlg = FALSE", "")) 
					trigger_error("Getting Reservation Failed.", E_USER_ERROR);
			}
			$myUser->Updater = $myUserCD;
			$myUser->ReplyFlg 	= "1";
			$myUser->ConfirmFlg = "1";
			if (!$myUser->executeUpdate())
				trigger_error("Updating myUser Failed.", E_USER_ERROR);
			recordBukkenTelActivity($myDB, $editBukkenCD);#TEL受付更新を協力会社へ通知
			SPFWTemplate::dropValue('work');
		}

	}
}

########################################################
# 詳細工程表表示
########################################################

#Koteihyoに、空きか部屋番号をいれていく。
########################################################
# 日程情報取得
########################################################
// SELECT 
//    DATE(TimeFrom) AS Date,
//     CASE 
//         WHEN TIME(TimeFrom) BETWEEN '09:00:00' AND '12:00:00' THEN 'AM'
//         WHEN TIME(TimeFrom) BETWEEN '13:00:00' AND '15:00:00' THEN 'PM1'
//         WHEN TIME(TimeFrom) BETWEEN '15:00:01' AND '18:00:00' THEN 'PM2'
//         ELSE 'Other'
//     END AS TimePeriod
// FROM tReservationF
// where BukkenCD = 217

$myListObject = new SPFWListObject($myDB);
$sql  = "SELECT ";
$sql .= "r.ReservationCD, "; #0
$sql .= "DATE(r.TimeFrom) AS Date, "; #1
if($wWakuPattern == '0' || $wWakuPattern == '1' || $wWakuPattern == '2'){ // 2枠
	$sql .= "CASE ";
	$sql .= " WHEN TIME(r.TimeFrom) BETWEEN '09:00:00' AND '12:00:00' THEN 'AM'";
	$sql .= " WHEN TIME(r.TimeFrom) BETWEEN '13:00:00' AND '18:00:00' THEN 'PM'";
	$sql .= " ELSE 'Other'";
	$sql .= " END AS AMPM ,"; #2
}else{ // 3枠
	$sql .= "CASE ";
	$sql .= " WHEN TIME(r.TimeFrom) BETWEEN '09:00:00' AND '12:00:00' THEN 'AM'";
	$sql .= " WHEN TIME(r.TimeFrom) BETWEEN '13:00:00' AND '14:59:00' THEN 'PM1'";
	$sql .= " WHEN TIME(r.TimeFrom) BETWEEN '15:00:00' AND '18:00:00' THEN 'PM2'";
	$sql .= " ELSE 'Other'";
	$sql .= " END AS AMPM ,"; #2
}
$sql .= "r.ID, "; #3
$sql .= "r.UserCD, "; #4
$sql .= "r.TimeFrom, "; #5
$sql .= "r.TimeTo, "; #6
$sql .= "u.LastName, "; #7
$sql .= "u.TEL, "; #8
$sql .= "r.Memo, "; #9
$sql .= "r.TimeExact, "; #10
$sql .= "r.TimeMeaning, "; #11
$sql .= "u.ReplyFlg, "; #12
$sql .= "u.ConfirmFlg, "; #13
$sql .= "r.HanNo, "; #14
$sql .= "r.ViewOrderNo, "; #15
$sql .= "u.EMail, "; #16
$sql .= "r.R003, "; #17 TEL受付: aki=空き枠, wakuover=枠越枠
$sql .= "CASE ";
$sql .= " WHEN u.ReplyFlg = 3 THEN '2'";
$sql .= " ELSE '1'";
$sql .= " END AS SubOrder"; #18


$myListObject->SelectSQL = $sql;
$sql  = " FROM tReservationF r, tUserM u ";
$sql .= " WHERE r.Status = 1 AND r.MukouFlg = FALSE AND r.UserCD = u.UserCD";
$sql .= " AND r.BukkenCD = " . $editBukkenCD;
if($editBuildingCD){
	$sql .= " AND r.BuildingCD = " . $editBuildingCD;
}else{
	$sql .= " AND r.BuildingCD IS NULL ";
}

// $sql .= " AND ClientCD = " . $wClientCD;

$myListObject->Condition = $sql;
$myListObject->Order = "Date, AMPM, r.HanNo, SubOrder, r.TimeFrom, r.Updated, r.ReservationCD";
$myListObject->Limit = "allpage";

if (!($myListObject->GetList(1)))
	trigger_error("Getting Reservation List Failed.", E_USER_ERROR);

$ReservationLoop = $myListObject->Rows;
$TimeExactHour = [];
$TimeExactMinutes = [];
$TimeMeaning = [];
$arrHanNo = [];
$arrViewOrderNo = [];
$arrSlotType = [];
$arrAmpm = [];

for ($i = 0; $i < $ReservationLoop; $i++) {
	$ReservationCD[$i] = $myListObject->GetValue($i, 0);
	$tDate = $myListObject->GetValue($i, 1);
	$AMPM = $myListObject->GetValue($i, 2);
	$ID[$i] = $myListObject->GetValue($i, 3);
	$Reserve[$tDate][$AMPM][] = $ID[$i];

	$UserCD[$i] = $myListObject->GetValue($i, 4);

	$UserData['LastName'][$ID[$i]] = $myListObject->GetValue($i, 7);
	$UserData['TEL'][$ID[$i]] 	= $myListObject->GetValue($i, 8);
	$UserData['EMail'][$ID[$i]] 	= $myListObject->GetValue($i, 16);
	$UserData['Memo'][$ID[$i]] 	= $myListObject->GetValue($i, 9);
	$UserData['ReplyFlg'][$ID[$i]] 	= $myListObject->GetValue($i, 12);
	$UserData['ConfirmFlg'][$ID[$i]] 	= $myListObject->GetValue($i, 13);

	$TimeExact 	= $myListObject->GetValue($i, 10);
	$TimeExactPieces = explode(":", $TimeExact);

	if(isset($TimeExactPieces[0]))
		$TimeExactHour[$ID[$i]] 	= $TimeExactPieces[0];
	else
		$TimeExactHour[$ID[$i]] 	= null;

	if(isset($TimeExactPieces[1]))
		$TimeExactMinutes[$ID[$i]] 	= $TimeExactPieces[1];
	else
		$TimeExactMinutes[$ID[$i]] 	= null;

	$TimeMeaning[$ID[$i]] 	= $myListObject->GetValue($i, 11);
	$arrHanNo[$ID[$i]] 	= $myListObject->GetValue($i, 14);
	$arrViewOrderNo[$ID[$i]] 	= $myListObject->GetValue($i, 15);
	$arrTimeFrom[$ID[$i]] 	= $myListObject->GetValue($i, 5);
	$arrSlotType[$ID[$i]] 	= $myListObject->GetValue($i, 17);
	$arrAmpm[$ID[$i]] 	= $AMPM;
}

// 初期予約情報を取得します。
$myListObjectInit = new SPFWListObject($myDB);
$sql  = "SELECT ";
$sql .= "r.ReservationCD, "; #0
$sql .= "DATE(r.TimeFrom) AS Date, "; #1
if($wWakuPattern == '0' || $wWakuPattern == '1' || $wWakuPattern == '2'){ // 2枠
	$sql .= "CASE ";
	$sql .= " WHEN TIME(r.TimeFrom) BETWEEN '09:00:00' AND '12:00:00' THEN 'AM'";
	$sql .= " WHEN TIME(r.TimeFrom) BETWEEN '13:00:00' AND '18:00:00' THEN 'PM'";
	$sql .= " ELSE 'Other'";
	$sql .= " END AS AMPM ,"; #2
}else{ // 3枠
	$sql .= "CASE ";
	$sql .= " WHEN TIME(r.TimeFrom) BETWEEN '09:00:00' AND '12:00:00' THEN 'AM'";
	$sql .= " WHEN TIME(r.TimeFrom) BETWEEN '13:00:00' AND '14:59:00' THEN 'PM1'";
	$sql .= " WHEN TIME(r.TimeFrom) BETWEEN '15:00:00' AND '18:00:00' THEN 'PM2'";
	$sql .= " ELSE 'Other'";
	$sql .= " END AS AMPM ,"; #2
}
$sql .= "r.ID, "; #3
$sql .= "r.UserCD, "; #4
$sql .= "r.TimeFrom, "; #5
$sql .= "r.TimeTo, "; #6
$sql .= "r.HanNo, "; #7
$sql .= "r.ViewOrderNo "; #8

$myListObjectInit->SelectSQL = $sql;
$sql  = " FROM tReservationInitF r, tUserM u ";
$sql .= " WHERE r.Status = 1 AND r.MukouFlg = FALSE AND r.UserCD = u.UserCD";
$sql .= " AND r.BukkenCD = " . $editBukkenCD;
if($editBuildingCD){
	$sql .= " AND r.BuildingCD = " . $editBuildingCD;
}else{
	$sql .= " AND r.BuildingCD IS NULL ";
}

// $sql .= " AND ClientCD = " . $wClientCD;

$myListObjectInit->Condition = $sql;
$myListObjectInit->Order = "Date, AMPM, r.HanNo, r.TimeFrom, r.Updated, r.ReservationCD";
$myListObjectInit->Limit = "allpage";

if (!($myListObjectInit->GetList(1)))
	trigger_error("Getting Reservation List Failed.", E_USER_ERROR);

$ReservationLoopInit = $myListObjectInit->Rows;
for ($i = 0; $i < $ReservationLoopInit; $i++) {
	$tDate = $myListObjectInit->GetValue($i, 1);
	$tDate = date("Y-m-d", strtotime($tDate));
	$AMPM = $myListObjectInit->GetValue($i, 2);
	$ID[$i] = $myListObjectInit->GetValue($i, 3);
	$HanNo = $myListObjectInit->GetValue($i, 7);
	$ReserveInit[$tDate][$AMPM][$HanNo][] = $ID[$i];
}

if($wWakuPattern == "" || !$ReservationLoop){
	echo ('<script>
if(confirm("作業日程登録がまだ終わっていないようです。\r\nブラウザで戻り、作業日程登録の各項目の入力をお願いします。\r\n作業日程登録ページへ移動しますか？")){
	location.href="./doc/s_make_kanryo2.php?rKey='.$rKey.'&editBukkenCD='.$editBukkenCD.'&editBuildingCD='.$editBuildingCD.'";
}else{
	location.href="./s_menu.php?rKey='.$rKey.'&editBukkenCD='.$editBukkenCD.'";
}
</script>');
}

######################################################################################

$declineResult = "なし";
if(isset($UserData['ReplyFlg']) && is_array($UserData['ReplyFlg']) && count($UserData['ReplyFlg']) > 0){
	ksort($UserData['ReplyFlg']);
	foreach($UserData['ReplyFlg'] as $declineNo => $aReplyFlg){
		if($aReplyFlg == '3'){
			if($declineResult == 'なし')
				$declineResult = '';

			$tID = $declineNo;
			$aLastName = $UserData['LastName'][$tID] ;
			$aTEL = $UserData['TEL'][$tID] ;
			$aEMail = $UserData['EMail'][$tID] ;
			$aMemo = $UserData['Memo'][$tID] ;
			$ReplyFlg = $UserData['ReplyFlg'][$tID] ;
			$ConfirmFlg = $UserData['ConfirmFlg'][$tID] ;
			$aTimeExactHour = $TimeExactHour[$tID];
			$aTimeExactMinutes = $TimeExactMinutes[$tID];
			if($aTimeExactHour || $aTimeExactMinutes)
				$aTimeExact = $aTimeExactHour.":".$aTimeExactMinutes;
			else
				$aTimeExact = null;
			$aTimeMeaning = $TimeMeaning[$tID];

			$declineResult .= '<div id="room_'.$tID.'" class="declineNo tooltip-container" onclick="clickBtn8(\''.$tID.'\' ,\''.$aLastName.'\' ,\''.$aTEL.'\',\''.$aMemo.'\' , \''.$SenyuDate.'\', \''.$SenyuDateTime.'\', \''.$WakuName.'\', \''.$aTimeExactHour.'\', \''.$aTimeExactMinutes.'\', \''.$aTimeMeaning.'\', \''.$abanNo.'\', \''.$ViewOrderNo.'\', \''.$ReplyFlg.'\', \''.$ConfirmFlg.'\' ,\''.$aEMail.'\' )">'.$declineNo;
				$declineResult .= '<div class="tooltip-text">';
					$declineResult .= '<span class="decline">「辞退」</span> <br>';
					$declineResult .= '<span class="lb">部屋番号:</span> '.$declineNo.'<br>';
					$declineResult .= '<span class="lb">名前:</span> '.$aLastName.'<br>';
					$declineResult .= '<span class="lb">連絡先:</span> '.$aTEL.'<br>';
					$declineResult .= '<span class="lb">メールアドレス:</span> '.$aEMail.'<br>';
					$declineResult .= '<span class="lb">時間指定:</span> '.$aTimeExact.' '.$aTimeMeaning.'<br>';
					$declineResult .= '<span class="lb">備考:</span> '.nl2br($aMemo).'<br>';
				$declineResult .= '</div>';
			$declineResult .= '</div>';
		}
	}

}

$wFrameOverflow = intval($wFrameOverflow);
// if($wArrangeType == '1'){
// 	$wFrameOverflow = 0;
// }

$wHansu = intval($wHansu);
$rowCountforDay = $wHansu;

for ($i = 0; $i < count($WAKUPATTERN[$wWakuPattern]['AMPM']); $i++) {
	$WakuName = $WAKUPATTERN[$wWakuPattern]['AMPM'][$i];
	$tempRowCountforDay = ceil((${'wWaku' . $WakuName}+$wFrameOverflow * $wHansu) / 5);
	if($tempRowCountforDay > $rowCountforDay)
		$rowCountforDay = $tempRowCountforDay;

	${'wWaku' . $WakuName . 'Col'} = ceil(${'wWaku' . $WakuName} / $wHansu)+$wFrameOverflow;
	${'wWaku' . $WakuName . 'ColSum'} = ${'wWaku' . $WakuName . 'Col'} * $wHansu;
	$wWakuColSum += ${'wWaku' . $WakuName . 'Col'};

	${'wWaku' . $WakuName . 'col'} = ceil(${'wWaku' . $WakuName} / $wHansu)+$wFrameOverflow;
	if($WakuName == 'PM')$wWakuPM1col = ${'wWaku' . $WakuName . 'Col'} ;
}

$rowCountforDay = ceil($rowCountforDay / $wHansu) * $wHansu;

for ($i = 0; $i < count($WAKUPATTERN[$wWakuPattern]['AMPM']); $i++) {
	$WakuName = $WAKUPATTERN[$wWakuPattern]['AMPM'][$i];

	$tempRowCountforDay = ceil((${'wWaku' . $WakuName}+$wFrameOverflow * $wHansu) / 5);
	if($tempRowCountforDay > $wHansu){
		${'wWaku' . $WakuName . 'Col'} = 5;
	}else{
		${'wWaku' . $WakuName . 'Col'} = ceil(${'wWaku' . $WakuName} / $rowCountforDay)+$wFrameOverflow;
	}

	${'wWaku' . $WakuName . 'ColSum'} = ${'wWaku' . $WakuName . 'Col'} * $rowCountforDay;
	$wWakuColSum += ${'wWaku' . $WakuName . 'Col'};

	${'wWaku' . $WakuName . 'col'} = ceil(${'wWaku' . $WakuName} / $rowCountforDay)+$wFrameOverflow;
	if($WakuName == 'PM')$wWakuPM1col = ${'wWaku' . $WakuName . 'Col'} ;
}

$EmptyFrameCount = 0;
########################################################
# 初日・土日祝考慮
########################################################

$wWakuSum1 = 0;
$wWakuSum2 = 0;

$week = ['日', '月', '火', '水', '木', '金', '土'];

for ($wi = 0; $wi < count($WAKUPATTERN[$wWakuPattern]['AMPM']); $wi++) {
	$wn = $WAKUPATTERN[$wWakuPattern]['AMPM'][$wi];
	${'Waku' . $wn . 'SlotMeta'} = array();
}

foreach($beforeReserveDay as $key => $aReserveDay){
	$date = new DateTime($aReserveDay);
	$aSyoniti = false;
	$beforeKojiHoliday[$key] = false;
	$beforeHoliday[$key] = false;

	$SenyuDate = $date->format('Y-m-d');
	$result = array_search($SenyuDate, $SHUKUJITULIST);
	$YoubiCD =  $date->format('w');
	if ($result !== false || $YoubiCD == 0 || $YoubiCD == 6) {
		$beforeHoliday[$key] = true;
	}
	if (count($wHolidayItems) > 0) { //休工日
		$beforeKojiHoliday[$key] = isFullDayHoliday($wHolidayItems, $SenyuDate);
	}
	for ($j = 0; $j < count($WAKUPATTERN[$wWakuPattern]['AMPM']); $j++) {
		$ViewOrderNo = 1;
		$WakuName = $WAKUPATTERN[$wWakuPattern]['AMPM'][$j];
		$SyonitiKouryo = false;
		if ($wFirstDateFeature == 1 && strpos($WakuName, 'AM') !== FALSE && $aSyoniti) {
			$SyonitiKouryo = true;
		}else if($wFirstDateFeature == 2 && (strpos($WakuName, 'AM') !== FALSE || strpos($WakuName, 'PM1') !== FALSE) && $aSyoniti){
			$SyonitiKouryo = true;
		}
#★★★ここから
		$ban_rooms = 1;
		$Overflows = 0;
		$max_ban = ceil(${'wWaku' . $WakuName} / $wHansu);
		$limit_ban = ceil(${'wWaku' . $WakuName . 'ColSum'} / $wHansu);
		$passed_rooms = 0;
		$x = 0;

		for ($k = 0; $k < ${'wWaku' . $WakuName . 'ColSum'}; $k++) {#10,8,8
			$dis_ban = floor($k / $limit_ban) + 1;
			if (!$beforeKojiHoliday[$key]) { //休工日以外
				$wakuRecordSlotType = null;
				if ($SyonitiKouryo) { //初日考慮でAMなら　空を入れる
					${'Waku' . $WakuName . 'Room'}[] = "";
				} else if (isSlotHoliday($wHolidayItems, $SenyuDate, $WakuName)) {
					${'Waku' . $WakuName . 'Room'}[] = "休工";
				} else if($ban_rooms > $max_ban && $ban_rooms <= $limit_ban){
					if($Overflows < $wFrameOverflow){
						$wakuRecordSlotType = _SLOT_LABEL_WAKUOVER;
						if(isset($Reserve[$SenyuDate][$WakuName][$x]) 
							&& (!$arrHanNo[$Reserve[$SenyuDate][$WakuName][$x]] || $arrHanNo[$Reserve[$SenyuDate][$WakuName][$x]] == $dis_ban)){
							// 辞退
							if(isset($UserData['ReplyFlg'][$Reserve[$SenyuDate][$WakuName][$x]]) && $UserData['ReplyFlg'][$Reserve[$SenyuDate][$WakuName][$x]] == '3'){
								${'Waku' . $WakuName . 'Room'}[] = _SLOT_LABEL_WAKUOVER;

								$passed_rooms ++;
								$x ++;
							}else{
								${'Waku' . $WakuName . 'Room'}[] = shListFormatOverflowRoom($Reserve[$SenyuDate][$WakuName][$x], $arrSlotType);
								$passed_rooms ++;
								$x ++;
							}
						}else{
							${'Waku' . $WakuName . 'Room'}[] = _SLOT_LABEL_WAKUOVER;

						}
						$EmptyFrameCount ++;
						$Overflows ++;
					}else{
						${'Waku' . $WakuName . 'Room'}[] = "";
					}
				}elseif(isset($Reserve[$SenyuDate][$WakuName][$x]) 
					&& (!$arrHanNo[$Reserve[$SenyuDate][$WakuName][$x]] || $arrHanNo[$Reserve[$SenyuDate][$WakuName][$x]] == $dis_ban)){
					// 辞退
					if(isset($UserData['ReplyFlg'][$Reserve[$SenyuDate][$WakuName][$x]]) && $UserData['ReplyFlg'][$Reserve[$SenyuDate][$WakuName][$x]] == '3'){
						${'Waku' . $WakuName . 'Room'}[] = _SLOT_LABEL_AKI;

						$passed_rooms ++;
						$EmptyFrameCount ++;
					}else{
						if($wArrangeType == '1' && RESERVE_USE_FLOOR_BINDING){
							$bReservedRooms = 0;
							// foreach($arrFloorReserveInfo as $floor => $FloorReserveInfo){
							// 	if(date("Y-m-d", strtotime($FloorReserveInfo["wFloorDay"])) == date("Y-m-d", strtotime($SenyuDate)) && $FloorReserveInfo["wFloorWaku"] == $WakuName){
							// 		$bReservedRooms += intval($FloorReserveInfo["wFloorCols"]);
							// 	}
							// }
							$tSenyuDate = date("Y-m-d", strtotime($SenyuDate));
							if(isset($ReserveInit[$tSenyuDate][$WakuName][$dis_ban]) && is_array($ReserveInit[$tSenyuDate][$WakuName][$dis_ban])){
								$bReservedRooms = count($ReserveInit[$tSenyuDate][$WakuName][$dis_ban]);
							}

							if($ban_rooms > $bReservedRooms){
								${'Waku' . $WakuName . 'Room'}[] = _SLOT_LABEL_AKI;
								$passed_rooms ++;
								$EmptyFrameCount ++;
							}else{
								$bCorrectFloor = false;
								// foreach($arrFloorReserveInfo as $floor => $FloorReserveInfo){
								// 	if(date("Y-m-d", strtotime($FloorReserveInfo["wFloorDay"])) == date("Y-m-d", strtotime($SenyuDate)) && $FloorReserveInfo["wFloorWaku"] == $WakuName){
								// 		if (preg_match('/^'.$floor.'\d{2}$/', $Reserve[$SenyuDate][$WakuName][$x])) {
								// 			$bCorrectFloor = true;
								// 			break;
								// 		}
								// 	}
								// }
								if(isset($ReserveInit[$tSenyuDate][$WakuName][$dis_ban]) && is_array($ReserveInit[$tSenyuDate][$WakuName][$dis_ban])){
									foreach($ReserveInit[$tSenyuDate][$WakuName][$dis_ban] as $ReserveInitRoom){
										if($ReserveInitRoom == $Reserve[$SenyuDate][$WakuName][$x]){
											$bCorrectFloor = true;
											break;
										}
									}
								}

								if($bCorrectFloor){
									${'Waku' . $WakuName . 'Room'}[] = $Reserve[$SenyuDate][$WakuName][$x];
								}else{
									${'Waku' . $WakuName . 'Room'}[] = shListFormatOverflowRoom($Reserve[$SenyuDate][$WakuName][$x], $arrSlotType);
									// $Overflows ++;
								}
								$passed_rooms ++;
								$x ++;
							}
						}else{
							${'Waku' . $WakuName . 'Room'}[] = $Reserve[$SenyuDate][$WakuName][$x];
							$passed_rooms ++;
							$x ++;
						}
					}
				}elseif (${'wWaku' . $WakuName} > $passed_rooms) { //残った最大工事枠数分は空き
					${'Waku' . $WakuName . 'Room'}[] = _SLOT_LABEL_AKI;

					$passed_rooms ++;
					$EmptyFrameCount ++;
				}else{
					if($Overflows < $wFrameOverflow){
						$wakuRecordSlotType = _SLOT_LABEL_WAKUOVER;
						${'Waku' . $WakuName . 'Room'}[] = _SLOT_LABEL_WAKUOVER;

						$Overflows ++;
					}else{
						${'Waku' . $WakuName . 'Room'}[] = "";
					}
				}	
				$ban_rooms ++;
				if($ban_rooms > $limit_ban){
					$ban_rooms = 1;
					$Overflows = 0;
				}
				shListRecordWakuSlotMeta(${'Waku' . $WakuName . 'Room'}, ${'Waku' . $WakuName . 'SlotMeta'}, $ViewOrderNo, $dis_ban, $SenyuDate, $wakuRecordSlotType);
				$ViewOrderNo ++;
			}
		}
	}
}

$date = new DateTime($SenyuStartDate);
for ($i = 0; $i < $SenyuDateCnt; $i++) {
	$Syoniti[$i] = false;
	$KojiHoliday[$i] = false;
	$holiday[$i] = false;


	if ($i == 0) {
		$Syoniti[$i] = true;
	}
	$SenyuDate = $date->format('Y-m-d');
	$result = array_search($SenyuDate, $SHUKUJITULIST);
	$YoubiCD =  $date->format('w');
	if ($result !== false || $YoubiCD == 0 || $YoubiCD == 6) {
		$holiday[$i] = true;
	}
	if (count($wHolidayItems) > 0) { //休工日
		$KojiHoliday[$i] = isFullDayHoliday($wHolidayItems, $SenyuDate);
	}
	for ($j = 0; $j < count($WAKUPATTERN[$wWakuPattern]['AMPM']); $j++) {
		$ViewOrderNo = 1;
		$WakuName = $WAKUPATTERN[$wWakuPattern]['AMPM'][$j];
		//空きを考慮した枠数を取得
		// ${'Waku' . $WakuName . 'Su'} = getWakuRoomSu($WakuName, $Syoniti[$i], $holiday[$i], ${'wWaku' . $WakuName}, $wFirstDateFeature);
		//初日考慮
		$SyonitiKouryo = false;
		if ($wFirstDateFeature == 1 && strpos($WakuName, 'AM') !== FALSE && $Syoniti[$i]) {
			$SyonitiKouryo = true;
		}else if($wFirstDateFeature == 2 && (strpos($WakuName, 'AM') !== FALSE || strpos($WakuName, 'PM1') !== FALSE) && $Syoniti[$i]){
			$SyonitiKouryo = true;
		}
#★★★ここから
		$ban_rooms = 1;
		$Overflows = 0;
		$max_ban = ceil(${'wWaku' . $WakuName} / $wHansu);
		$limit_ban = ceil(${'wWaku' . $WakuName . 'ColSum'} / $wHansu);
		$passed_rooms = 0;
		$x = 0;

		for ($k = 0; $k < ${'wWaku' . $WakuName . 'ColSum'}; $k++) {#10,8,8
			$dis_ban = floor($k / $limit_ban) + 1;
			if (!$KojiHoliday[$i]) { //休工日以外
				$wakuRecordSlotType = null;
				if ($SyonitiKouryo) { //初日考慮でAMなら　空を入れる
					${'Waku' . $WakuName . 'Room'}[] = "";
				} else if (isSlotHoliday($wHolidayItems, $SenyuDate, $WakuName)) {
					${'Waku' . $WakuName . 'Room'}[] = "休工";
				} else if($ban_rooms > $max_ban && $ban_rooms <= $limit_ban){
					if($Overflows < $wFrameOverflow){
						$wakuRecordSlotType = _SLOT_LABEL_WAKUOVER;
						if(isset($Reserve[$SenyuDate][$WakuName][$x]) 
							&& (!$arrHanNo[$Reserve[$SenyuDate][$WakuName][$x]] || $arrHanNo[$Reserve[$SenyuDate][$WakuName][$x]] == $dis_ban)){
							// 辞退
							if(isset($UserData['ReplyFlg'][$Reserve[$SenyuDate][$WakuName][$x]]) && $UserData['ReplyFlg'][$Reserve[$SenyuDate][$WakuName][$x]] == '3'){
								${'Waku' . $WakuName . 'Room'}[] = _SLOT_LABEL_WAKUOVER;

								$passed_rooms ++;
								$x ++;
							}else{
								${'Waku' . $WakuName . 'Room'}[] = shListFormatOverflowRoom($Reserve[$SenyuDate][$WakuName][$x], $arrSlotType);
								$passed_rooms ++;
								$x ++;
							}
						}else{
							${'Waku' . $WakuName . 'Room'}[] = _SLOT_LABEL_WAKUOVER;
						}
						$EmptyFrameCount ++;
						$Overflows ++;
					}else{
						${'Waku' . $WakuName . 'Room'}[] = "";
					}
				}elseif(isset($Reserve[$SenyuDate][$WakuName][$x]) 
					&& (!$arrHanNo[$Reserve[$SenyuDate][$WakuName][$x]] || $arrHanNo[$Reserve[$SenyuDate][$WakuName][$x]] == $dis_ban)){
					// 辞退
					if(isset($UserData['ReplyFlg'][$Reserve[$SenyuDate][$WakuName][$x]]) && $UserData['ReplyFlg'][$Reserve[$SenyuDate][$WakuName][$x]] == '3'){
						${'Waku' . $WakuName . 'Room'}[] = _SLOT_LABEL_AKI;

						$passed_rooms ++;
						$EmptyFrameCount ++;
						$x ++;
					}else{
						if($wArrangeType == '1' && RESERVE_USE_FLOOR_BINDING){
							// 仮日程の場合は、チェックを行わずに表示します。
							if(empty($UserData['ReplyFlg'][$Reserve[$SenyuDate][$WakuName][$x]]) && empty($UserData['ConfirmFlg'][$Reserve[$SenyuDate][$WakuName][$x]])){
								${'Waku' . $WakuName . 'Room'}[] = $Reserve[$SenyuDate][$WakuName][$x];
								$passed_rooms ++;
								$x ++;
							}else{
								$bReservedRooms = 0;
								// foreach($arrFloorReserveInfo as $floor => $FloorReserveInfo){
								// 	if(date("Y-m-d", strtotime($FloorReserveInfo["wFloorDay"])) == date("Y-m-d", strtotime($SenyuDate)) && $FloorReserveInfo["wFloorWaku"] == $WakuName){
								// 		$bReservedRooms += intval($FloorReserveInfo["wFloorCols"]);
								// 	}
								// }
								$tSenyuDate = date("Y-m-d", strtotime($SenyuDate));
								if(isset($ReserveInit[$tSenyuDate][$WakuName][$dis_ban]) && is_array($ReserveInit[$tSenyuDate][$WakuName][$dis_ban])){
									$bReservedRooms = count($ReserveInit[$tSenyuDate][$WakuName][$dis_ban]);
								}

								if($ban_rooms > $bReservedRooms){
									${'Waku' . $WakuName . 'Room'}[] = _SLOT_LABEL_AKI;
									$passed_rooms ++;
									$EmptyFrameCount ++;
								}else{
									$bCorrectFloor = false;
									// foreach($arrFloorReserveInfo as $floor => $FloorReserveInfo){
									// 	if(date("Y-m-d", strtotime($FloorReserveInfo["wFloorDay"])) == date("Y-m-d", strtotime($SenyuDate)) && $FloorReserveInfo["wFloorWaku"] == $WakuName){
									// 		if (preg_match('/^'.$floor.'\d{2}$/', $Reserve[$SenyuDate][$WakuName][$x])) {
									// 			$bCorrectFloor = true;
									// 			break;
									// 		}
									// 	}
									// }
									if(isset($ReserveInit[$tSenyuDate][$WakuName][$dis_ban]) && is_array($ReserveInit[$tSenyuDate][$WakuName][$dis_ban])){
										foreach($ReserveInit[$tSenyuDate][$WakuName][$dis_ban] as $ReserveInitRoom){
											if($ReserveInitRoom == $Reserve[$SenyuDate][$WakuName][$x]){
												$bCorrectFloor = true;
												break;
											}
										}
									}

									if($bCorrectFloor){
										${'Waku' . $WakuName . 'Room'}[] = $Reserve[$SenyuDate][$WakuName][$x];
									}else{
										${'Waku' . $WakuName . 'Room'}[] = shListFormatOverflowRoom($Reserve[$SenyuDate][$WakuName][$x], $arrSlotType);
										// $Overflows ++;
									}
									$passed_rooms ++;
									$x ++;
								}

							}
						}else{
							${'Waku' . $WakuName . 'Room'}[] = $Reserve[$SenyuDate][$WakuName][$x];
							$passed_rooms ++;
							$x ++;
						}
					}
				}elseif (${'wWaku' . $WakuName} > $passed_rooms) { //残った最大工事枠数分は空き
					${'Waku' . $WakuName . 'Room'}[] = _SLOT_LABEL_AKI;

					$passed_rooms ++;
					$EmptyFrameCount ++;
				}else{
					if($Overflows < $wFrameOverflow){
						$wakuRecordSlotType = _SLOT_LABEL_WAKUOVER;
						${'Waku' . $WakuName . 'Room'}[] = _SLOT_LABEL_WAKUOVER;

						$Overflows ++;
						$EmptyFrameCount ++;
					}else{
						${'Waku' . $WakuName . 'Room'}[] = "";
					}
				}	
				$ban_rooms ++;
				if($ban_rooms > $limit_ban){
					$ban_rooms = 1;
					$Overflows = 0;
				}
				shListRecordWakuSlotMeta(${'Waku' . $WakuName . 'Room'}, ${'Waku' . $WakuName . 'SlotMeta'}, $ViewOrderNo, $dis_ban, $SenyuDate, $wakuRecordSlotType);
				$ViewOrderNo ++;
			}
			// if (!$KojiHoliday[$i]) { //休工日以外
				// if ($SyonitiKouryo) { //初日考慮でAMなら　空を入れる
				// 	${'Waku' . $WakuName . 'Room'}[] = "";
				// } elseif (${'Waku' . $WakuName . 'Su'} > $k && isset($KaiRoom3[$x])) { //空きを考慮した枠数分　部屋を入れる
				// 	${'Waku' . $WakuName . 'Room'}[] = $KaiRoom3[$x];
				// 	$x++;
				// } elseif (${'wWaku' . $WakuName} > $k) { //残った最大工事枠数分は空き
				// 	${'Waku' . $WakuName . 'Room'}[] = _SLOT_LABEL_AKI;
				// } else {
				// 	${'Waku' . $WakuName . 'Room'}[] = "";
				// }
			// }
		}
	}
	$date->modify('+1 days');
}

foreach($afterReserveDay as $key => $aReserveDay){
	$date = new DateTime($aReserveDay);
	$aSyoniti = false;
	$afterKojiHoliday[$key] = false;
	$afterHoliday[$key] = false;

	$SenyuDate = $date->format('Y-m-d');
	$result = array_search($SenyuDate, $SHUKUJITULIST);
	$YoubiCD =  $date->format('w');
	if ($result !== false || $YoubiCD == 0 || $YoubiCD == 6) {
		$afterHoliday[$key] = true;
	}
	if (count($wHolidayItems) > 0) { //休工日
		$afterKojiHoliday[$key] = isFullDayHoliday($wHolidayItems, $SenyuDate);
	}
	for ($j = 0; $j < count($WAKUPATTERN[$wWakuPattern]['AMPM']); $j++) {
		$ViewOrderNo = 1;
		$WakuName = $WAKUPATTERN[$wWakuPattern]['AMPM'][$j];
		$SyonitiKouryo = false;
		if ($wFirstDateFeature == 1 && strpos($WakuName, 'AM') !== FALSE && $aSyoniti) {
			$SyonitiKouryo = true;
		}else if($wFirstDateFeature == 2 && (strpos($WakuName, 'AM') !== FALSE || strpos($WakuName, 'PM1') !== FALSE) && $aSyoniti){
			$SyonitiKouryo = true;
		}
#★★★ここから
		$ban_rooms = 1;
		$Overflows = 0;
		$max_ban = ceil(${'wWaku' . $WakuName} / $wHansu);
		$limit_ban = ceil(${'wWaku' . $WakuName . 'ColSum'} / $wHansu);
		$passed_rooms = 0;
		$x = 0;

		for ($k = 0; $k < ${'wWaku' . $WakuName . 'ColSum'}; $k++) {#10,8,8
			$dis_ban = floor($k / $limit_ban) + 1;
			if (!$afterKojiHoliday[$key]) { //休工日以外
				$wakuRecordSlotType = null;
				if ($SyonitiKouryo) { //初日考慮でAMなら　空を入れる
					${'Waku' . $WakuName . 'Room'}[] = "";
				} else if (isSlotHoliday($wHolidayItems, $SenyuDate, $WakuName)) {
					${'Waku' . $WakuName . 'Room'}[] = "休工";
				} else if($ban_rooms > $max_ban && $ban_rooms <= $limit_ban){
					if($Overflows < $wFrameOverflow){
						$wakuRecordSlotType = _SLOT_LABEL_WAKUOVER;
						if(isset($Reserve[$SenyuDate][$WakuName][$x]) 
							&& (!$arrHanNo[$Reserve[$SenyuDate][$WakuName][$x]] || $arrHanNo[$Reserve[$SenyuDate][$WakuName][$x]] == $dis_ban)){
							// 辞退
							if(isset($UserData['ReplyFlg'][$Reserve[$SenyuDate][$WakuName][$x]]) && $UserData['ReplyFlg'][$Reserve[$SenyuDate][$WakuName][$x]] == '3'){
								${'Waku' . $WakuName . 'Room'}[] = _SLOT_LABEL_WAKUOVER;

								$passed_rooms ++;
								$x ++;
							}else{
								${'Waku' . $WakuName . 'Room'}[] = shListFormatOverflowRoom($Reserve[$SenyuDate][$WakuName][$x], $arrSlotType);
								$passed_rooms ++;
								$x ++;
							}
						}else{
							${'Waku' . $WakuName . 'Room'}[] = _SLOT_LABEL_WAKUOVER;
						}
						$EmptyFrameCount ++;
						$Overflows ++;
					}else{
						${'Waku' . $WakuName . 'Room'}[] = "";
					}
				}elseif(isset($Reserve[$SenyuDate][$WakuName][$x]) 
					&& (!$arrHanNo[$Reserve[$SenyuDate][$WakuName][$x]] || $arrHanNo[$Reserve[$SenyuDate][$WakuName][$x]] == $dis_ban)){
					// 辞退
					if(isset($UserData['ReplyFlg'][$Reserve[$SenyuDate][$WakuName][$x]]) && $UserData['ReplyFlg'][$Reserve[$SenyuDate][$WakuName][$x]] == '3'){
						${'Waku' . $WakuName . 'Room'}[] = _SLOT_LABEL_AKI;

						$passed_rooms ++;
						$EmptyFrameCount ++;
					}else{
						if($wArrangeType == '1' && RESERVE_USE_FLOOR_BINDING){
							$bReservedRooms = 0;
							// foreach($arrFloorReserveInfo as $floor => $FloorReserveInfo){
							// 	if(date("Y-m-d", strtotime($FloorReserveInfo["wFloorDay"])) == date("Y-m-d", strtotime($SenyuDate)) && $FloorReserveInfo["wFloorWaku"] == $WakuName){
							// 		$bReservedRooms += intval($FloorReserveInfo["wFloorCols"]);
							// 	}
							// }
							$tSenyuDate = date("Y-m-d", strtotime($SenyuDate));
							if(isset($ReserveInit[$tSenyuDate][$WakuName][$dis_ban]) && is_array($ReserveInit[$tSenyuDate][$WakuName][$dis_ban])){
								$bReservedRooms = count($ReserveInit[$tSenyuDate][$WakuName][$dis_ban]);
							}

							if($ban_rooms > $bReservedRooms){
								${'Waku' . $WakuName . 'Room'}[] = _SLOT_LABEL_AKI;
								$passed_rooms ++;
								$EmptyFrameCount ++;
							}else{
								$bCorrectFloor = false;
								// foreach($arrFloorReserveInfo as $floor => $FloorReserveInfo){
								// 	if(date("Y-m-d", strtotime($FloorReserveInfo["wFloorDay"])) == date("Y-m-d", strtotime($SenyuDate)) && $FloorReserveInfo["wFloorWaku"] == $WakuName){
								// 		if (preg_match('/^'.$floor.'\d{2}$/', $Reserve[$SenyuDate][$WakuName][$x])) {
								// 			$bCorrectFloor = true;
								// 			break;
								// 		}
								// 	}
								// }
								if(isset($ReserveInit[$tSenyuDate][$WakuName][$dis_ban]) && is_array($ReserveInit[$tSenyuDate][$WakuName][$dis_ban])){
									foreach($ReserveInit[$tSenyuDate][$WakuName][$dis_ban] as $ReserveInitRoom){
										if($ReserveInitRoom == $Reserve[$SenyuDate][$WakuName][$x]){
											$bCorrectFloor = true;
											break;
										}
									}
								}

								if($bCorrectFloor){
									${'Waku' . $WakuName . 'Room'}[] = $Reserve[$SenyuDate][$WakuName][$x];
								}else{
									${'Waku' . $WakuName . 'Room'}[] = shListFormatOverflowRoom($Reserve[$SenyuDate][$WakuName][$x], $arrSlotType);
									// $Overflows ++;
								}
								$passed_rooms ++;
								$x ++;
							}
						}else{
							${'Waku' . $WakuName . 'Room'}[] = $Reserve[$SenyuDate][$WakuName][$x];
							$passed_rooms ++;
							$x ++;
						}
					}
				}elseif (${'wWaku' . $WakuName} > $passed_rooms) { //残った最大工事枠数分は空き
					${'Waku' . $WakuName . 'Room'}[] = _SLOT_LABEL_AKI;

					$passed_rooms ++;
					$EmptyFrameCount ++;
				}else{
					if($Overflows < $wFrameOverflow){
						$wakuRecordSlotType = _SLOT_LABEL_WAKUOVER;
						${'Waku' . $WakuName . 'Room'}[] = _SLOT_LABEL_WAKUOVER;

						$Overflows ++;
					}else{
						${'Waku' . $WakuName . 'Room'}[] = "";
					}
				}	
				$ban_rooms ++;
				if($ban_rooms > $limit_ban){
					$ban_rooms = 1;
					$Overflows = 0;
				}
				shListRecordWakuSlotMeta(${'Waku' . $WakuName . 'Room'}, ${'Waku' . $WakuName . 'SlotMeta'}, $ViewOrderNo, $dis_ban, $SenyuDate, $wakuRecordSlotType);
				$ViewOrderNo ++;
			}
		}
	}
}
for ($wi = 0; $wi < count($WAKUPATTERN[$wWakuPattern]['AMPM']); $wi++) {
	$wn = $WAKUPATTERN[$wWakuPattern]['AMPM'][$wi];
	shListApplyBlankSlotAssignments(
		${'Waku' . $wn . 'Room'},
		${'Waku' . $wn . 'SlotMeta'},
		$arrViewOrderNo,
		$arrHanNo,
		$arrSlotType,
		$arrTimeFrom,
		$wn,
		$arrAmpm
	);
}
########################################################
# 詳細工程表（イメージ）部分
########################################################

$Koteihyou = "<table border='1' width='600px' cellspacing='5' style='text-align:center' cellpadding='7' class='ex_table'>";
$Koteihyou .= "<tr><td class='ex_table2' width='130px'>日程</td>";
$Koteihyou .= "<td class='ex_table2' width='60px'>曜日</td>";
$Koteihyou .= "<td class='ex_table2' width='50px'>班</td>";
for ($i = 0; $i < count($WAKUPATTERN[$wWakuPattern]['AMPM']); $i++) {
	$WakuName = $WAKUPATTERN[$wWakuPattern]['AMPM'][$i];
	$disWakuName = $WakuName;
	$WakuPatternNames = $WAKUPATTERN[$wWakuPattern]['Name'];
	if (preg_match('/\((.*?)\)/', $WakuPatternNames, $matches)) {
		$WakuPatternNamesStr = $matches[1];
		$WakuPatternNamesArr = explode(",", $WakuPatternNamesStr);
		if(isset($WakuPatternNamesArr[$i]) && $WakuPatternNamesArr[$i] != '')
			$disWakuName = trim($WakuPatternNamesArr[$i]);
	}

	$Koteihyou .= "<td colspan = " . ${'wWaku' . $WakuName . 'Col'};
	if ($i % 2 == 0) {
		$Koteihyou .= " style='background-color:#add8e6;' ";
	} else {
		$Koteihyou .= " style='background-color:#e0ffff;' ";
	}
	$Koteihyou .= "class='ex_table2'>" . $disWakuName."</td>";

	${$WakuName . "index"} = 0;
	// echo "<pre>";
	// var_dump(${'Waku' . $WakuName . 'Room'});
	// echo "</pre>";

	${"wWaku".$WakuName."col"} = ${'wWaku' . $WakuName . 'Col'} ;#大文字、小文字がちがう！
	#echo "<br> ".__LINE__." Hensu :".${"wWaku".$WakuName."col"};
	

}
$Koteihyou .= "</tr>";
$holiday = array();

for ($k = 0; $k < count($WAKUPATTERN[$wWakuPattern]['AMPM']); ++$k) {
	$starttime = strtotime($WAKUPATTERN[$wWakuPattern]['StartTime'][$k]);
	$endtime   = strtotime($WAKUPATTERN[$wWakuPattern]['EndTime'][$k]);
	$minutes = ($endtime - $starttime) / 60;
	$MinuteTime = intval($MinuteTime);
	$countForTimeZoneOfDate = ceil($minutes / $MinuteTime);
	$countMax = intval($MaxWaku[$k]);
	$countRepeat = ceil($countMax / $countForTimeZoneOfDate);
	if($countRepeat < 1)
		$countRepeat = 1;
	$arrCountRepeat[$k] = $countRepeat;
}

foreach($beforeReserveDay as $key => $aReserveDay){
	$date = new DateTime($aReserveDay);
	$SenyuDate = $date->format('Y-m-d');
	$NextBlankTime = [];
	$NextBlankContinusCount = [];
	$week_str = $week[$date->format('w')];
	if($week_str == '土')
		$week_str = '<span style="color:#0070c0">'.$week_str.'</span>';
	else if($week_str == '日')
		$week_str = '<span style="color:#ff9999">'.$week_str.'</span>';

	if ($beforeKojiHoliday[$key]) { #★１休工日なら
		if ($beforeHoliday[$key]) { //土日祝なら
			$Koteihyou .= "<tr class='trtop trreserveday' id='row".$SenyuDate."'><td class='ex_table2' style='vertical-align:top'><span class='senyu_date'>" . $SenyuDate . "</span><div class='reserve_day'>予備日</div></td>";
			$Koteihyou .= "<td  class='ex_table2' style='vertical-align:top'>" . $week_str . "</td>";
			$Koteihyou .= "<td  class='ex_table2'></td>";
		} else { //平日なら
			$Koteihyou .= "<tr class='trtop trreserveday' id='row".$SenyuDate."'><td  class='ex_table2' style='vertical-align:top'><span class='senyu_date'>" . $SenyuDate . "</span><div class='reserve_day'>予備日</div></td>";
			$Koteihyou .= "<td class='ex_table2' style='vertical-align:top'>" . $week_str . "</td>";
			$Koteihyou .= "<td class='ex_table2'></td>";
		}
		$Koteihyou .= "<td colspan=" . $wWakuColSum . " class='ex_table2'>";
		$Koteihyou .= "休工日</td>";
	} else { #★１休工日でない場合
		if ($beforeHoliday[$key]) { //土日祝なら
			$Koteihyou .= "<tr class='trtop trreserveday' id='row".$SenyuDate."'><td rowspan=" . $rowCountforDay . " class='ex_table2' style='vertical-align:top'><span class='senyu_date'>" . $SenyuDate . "</span><div class='reserve_day'>予備日</div>@@blank_count@@</td>";
			$Koteihyou .= "<td rowspan=" . $rowCountforDay . " class='ex_table2' style='vertical-align:top'>" . $week_str . "</td>";
		} else { //平日なら
			$Koteihyou .= "<tr class='trtop trreserveday' id='row".$SenyuDate."'><td rowspan=" . $rowCountforDay . " class='ex_table2' style='vertical-align:top'><span class='senyu_date'>" . $SenyuDate . "</span><div class='reserve_day'>予備日</div>@@blank_count@@</td>";
			$Koteihyou .= "<td rowspan=" . $rowCountforDay . " class='ex_table2' style='vertical-align:top'>" . $week_str . "</td>";
		}
		$banNo = 1;
		$abanNo = $banNo;
		$banRowspan = floor($rowCountforDay / $wHansu);
		$arrBlankCount = [];

		for ($j = 0; $j < $rowCountforDay; $j++) {
			if ($j != 0)
				$Koteihyou .= "<tr class='trreserveday'>";

			if($j % $banRowspan == 0){
				if ($beforeHoliday[$key]) { //土日祝なら
					$Koteihyou .= "<td rowspan=" . $banRowspan . " class='ex_table2' style='vertical-align:top'>" . $banNo . "</td>";
				} else { //平日なら
					$Koteihyou .= "<td rowspan=" . $banRowspan . " class='ex_table2' style='vertical-align:top'>" . $banNo . "</td>";
				}
				$abanNo = $banNo;
				$banNo ++;
			}
	
			for ($k = 0; $k < count($WAKUPATTERN[$wWakuPattern]['AMPM']); $k++) {
				$WakuEndtime   = date('H:i', strtotime($WAKUPATTERN[$wWakuPattern]['EndTime'][$k]));

				$WakuName = $WAKUPATTERN[$wWakuPattern]['AMPM'][$k];
				if(!isset($arrBlankCount[$WakuName]))
					$arrBlankCount[$WakuName] = 0;
				$WakuStart = $WAKUPATTERN[$wWakuPattern]['StartTime'][$k];
				if(!isset($NextBlankTime[$WakuName])){
					$NextBlankTime[$WakuName] = date('H:i', strtotime($WakuStart));
				}
				if(!isset($NextBlankContinusCount[$WakuName])){
					$NextBlankContinusCount[$WakuName] = 1;
				}

				for ($l = 0; $l < ${'wWaku' . $WakuName . 'Col'}; $l++) {
					$ViewOrderNo = $l + 1 + $j * ${'wWaku' . $WakuName . 'Col'};
					$Koteihyou_event = "";

					if ($k % 2 == 0) {
						$Koteihyou_temp = "<td class='link_cell' style='background-color:#ffff9e;' @event@>";
					} else {
						$Koteihyou_temp = "<td class='link_cell' style='background-color:#ffffcf;' @event@>";
					}
					if (!${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}]) {
						$Koteihyou_temp = "<td class='link_cell link_cell_none no-action' style='background-color:#d3d3d3; cursor:default'>";
					}

					if (${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}] == "休工") {
						$Koteihyou_temp = "<td class='link_cell link_cell_none no-action' style='background-color:#d3d3d3; cursor:default'>休工";
						$Koteihyou_event = "";
					} else if (isSlotLabelAki(${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}])) {
						if ($k % 2 == 0) {
							$Koteihyou_temp = "<td class='link_cell_blank' style='background-color:#ffff9e;' @event@>";
						} else {
							$Koteihyou_temp = "<td class='link_cell_blank' style='background-color:#ffffcf;' @event@>";
						}

						$Koteihyou_temp .= ${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}];
						$Koteihyou_event = "onclick=\"clickBtn7('".$SenyuDate."', '".$NextBlankTime[$WakuName]."', '".$WakuName."', '".$abanNo."', '".$ViewOrderNo."', 'aki')\"";
						$arrBlankCount[$WakuName] ++;
						$NextBlankTime[$WakuName] = date('H:i', strtotime("+".(floor($NextBlankContinusCount[$WakuName] / $arrCountRepeat[$k])*$MinuteTime)." minutes", strtotime($NextBlankTime[$WakuName])));
						if($NextBlankTime[$WakuName] > $WakuEndtime)
							$NextBlankTime[$WakuName] = $WakuEndtime;
						$NextBlankContinusCount[$WakuName] ++;
						if($NextBlankContinusCount[$WakuName] > $arrCountRepeat[$k]){
							$NextBlankContinusCount[$WakuName] = 1;
						}
					}else if (isSlotLabelWakuover(${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}])) {
						if ($k % 2 == 0) {
							$Koteihyou_temp = "<td class='link_cell_blank' style='background-color:#ffff9e; color:#f94a4a' @event@>";
						} else {
							$Koteihyou_temp = "<td class='link_cell_blank' style='background-color:#ffffcf; color:#f94a4a' @event@>";
						}

						$Koteihyou_temp .= ${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}];
						$Koteihyou_event = "onclick=\"clickBtn7('".$SenyuDate."', '".$NextBlankTime[$WakuName]."', '".$WakuName."', '".$abanNo."', '".$ViewOrderNo."', 'wakuover')\"";
						$NextBlankTime[$WakuName] = date('H:i', strtotime("+".(floor($NextBlankContinusCount[$WakuName] / $arrCountRepeat[$k])*$MinuteTime)." minutes", strtotime($NextBlankTime[$WakuName])));
						if($NextBlankTime[$WakuName] > $WakuEndtime)
							$NextBlankTime[$WakuName] = $WakuEndtime;
						$NextBlankContinusCount[$WakuName] ++;
						if($NextBlankContinusCount[$WakuName] > $arrCountRepeat[$k]){
							$NextBlankContinusCount[$WakuName] = 1;
						}
					}else if(${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}]) {
						$tID = ${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}];
						$disRoom =$tID;
						$disTooltipRoom =$tID;
						$link_color = "";
						if (strpos($tID, 'overflow@') !== false) {
							$disRoom = '<span style="color:#f94a4a">'.str_replace('overflow@', '', $tID).'</span>';
							$disTooltipRoom = str_replace('overflow@', '', $tID);
							$link_color = "color:#f94a4a";
						}

						if ($k % 2 == 0) {
							$Koteihyou_temp = "<td id='room_".$disTooltipRoom."' class='link_cell' style='background-color:#ffff9e;' @event@>";
						} else {
							$Koteihyou_temp = "<td id='room_".$disTooltipRoom."' class='link_cell' style='background-color:#ffffcf;' @event@>";
						}

						$aLastName = $UserData['LastName'][$disTooltipRoom] ;
						$aTEL = $UserData['TEL'][$disTooltipRoom] ;
						$aEMail = $UserData['EMail'][$disTooltipRoom] ;
						$aMemo = $UserData['Memo'][$disTooltipRoom] ;
						$ReplyFlg = $UserData['ReplyFlg'][$disTooltipRoom] ;
						$ConfirmFlg = $UserData['ConfirmFlg'][$disTooltipRoom] ;
						$aTimeExactHour = $TimeExactHour[$disTooltipRoom];
						$aTimeExactMinutes = $TimeExactMinutes[$disTooltipRoom];
						if($aTimeExactHour || $aTimeExactMinutes)
							$aTimeExact = $aTimeExactHour.":".$aTimeExactMinutes;
						else
							$aTimeExact = null;
						$aTimeMeaning = $TimeMeaning[$disTooltipRoom];
						if($aTimeExact){
							$Koteihyou_temp .= '<div class="multi_val tooltip-container">';
								$Koteihyou_temp .= '<font class="haslink" style="font-size:20px; text-decoration:underline;'. $link_color .'"> <b>' . $disRoom . '</b></font>';
								$Koteihyou_temp .= '<div class="exact_time">'.$aTimeExact.'</div>';
								$Koteihyou_temp .= '<div class="tooltip-text">';
									if($ReplyFlg == '3')
										$Koteihyou_temp .= '<span class="decline">「辞退」</span> <br>';
									else
										$Koteihyou_temp .= '<span class="confirmed">「確定」</span> <br>';
									$Koteihyou_temp .= '<span class="lb">部屋番号:</span> '.$disTooltipRoom.'<br>';
									$Koteihyou_temp .= '<span class="lb">名前:</span> '.$aLastName.'<br>';
									$Koteihyou_temp .= '<span class="lb">連絡先:</span> '.$aTEL.'<br>';
									$Koteihyou_temp .= '<span class="lb">メールアドレス:</span> '.$aEMail.'<br>';
									$Koteihyou_temp .= '<span class="lb">時間指定:</span> '.$aTimeExact.' '.$aTimeMeaning.'<br>';
									$Koteihyou_temp .= '<span class="lb">備考:</span> '.nl2br($aMemo).'<br>';
								$Koteihyou_temp .= '</div>';
							$Koteihyou_temp .= '</div>';

						}else if($ReplyFlg || $ConfirmFlg){
							$Koteihyou_temp .= '<font class="haslink tooltip-container" style="font-size:20px; text-decoration:underline;' . $link_color . '"> <b>' . $disRoom . '</b>';
								$Koteihyou_temp .= '<div class="tooltip-text">';
									if($ReplyFlg == '3')
										$Koteihyou_temp .= '<span class="decline">「辞退」</span> <br>';
									else
										$Koteihyou_temp .= '<span class="confirmed">「確定」</span> <br>';
									$Koteihyou_temp .= '<span class="lb">部屋番号:</span> '.$disTooltipRoom.'<br>';
									$Koteihyou_temp .= '<span class="lb">名前:</span> '.$aLastName.'<br>';
									$Koteihyou_temp .= '<span class="lb">連絡先:</span> '.$aTEL.'<br>';
									$Koteihyou_temp .= '<span class="lb">メールアドレス:</span> '.$aEMail.'<br>';
									$Koteihyou_temp .= '<span class="lb">時間指定:</span> '.$aTimeExact.' '.$aTimeMeaning.'<br>';
									$Koteihyou_temp .= '<span class="lb">備考:</span> '.nl2br($aMemo).'<br>';
								$Koteihyou_temp .= '</div>';
							$Koteihyou_temp .= '</font>';
						
						}else{
							$Koteihyou_temp .= '<font class="tooltip-container" style="font-size:20px"> <b>' . $disRoom . '</b>';
								$Koteihyou_temp .= '<div class="tooltip-text">';
									$Koteihyou_temp .= '<span class="temporary">「仮日程」</span> <br>';
									$Koteihyou_temp .= '<span class="lb">部屋番号:</span> '.$disTooltipRoom.'<br>';
								$Koteihyou_temp .= '</div>';
							$Koteihyou_temp .= '</font>';
						}
						$NextBlankTime[$WakuName] = isset($arrTimeFrom[$disTooltipRoom])?$arrTimeFrom[$disTooltipRoom]:$WakuStart;
						$NextBlankTime[$WakuName] = date('H:i', strtotime($NextBlankTime[$WakuName]));
						if($NextBlankTime[$WakuName] > $WakuEndtime)
							$NextBlankTime[$WakuName] = $WakuEndtime;
						$Koteihyou_event = "onclick=\"clickBtn8('".$disTooltipRoom."' ,'".$aLastName."'  ,'".$aTEL."','".$aMemo."' , '".$SenyuDate."', '".$NextBlankTime[$WakuName]."', '".$WakuName."', '".$aTimeExactHour."', '".$aTimeExactMinutes."', '".$aTimeMeaning."', '".$abanNo."', '".$ViewOrderNo."', '".$ReplyFlg."', '".$ConfirmFlg."' ,'".$aEMail."' )\"";
						$NextBlankTime[$WakuName] = date('H:i', strtotime("+$MinuteTime minutes", strtotime($NextBlankTime[$WakuName])));
						if($NextBlankTime[$WakuName] > $WakuEndtime)
							$NextBlankTime[$WakuName] = $WakuEndtime;
						$NextBlankContinusCount[$WakuName] = 1;
					}
					// $KoteihyouEX[] = $tID;

					// echo "<br>" . $WakuName . ":" . ${$WakuName . "index"};
					$Koteihyou_temp = str_replace("@event@", $Koteihyou_event, $Koteihyou_temp);
					$Koteihyou .= $Koteihyou_temp;

					$Koteihyou .= "</td>";
					${$WakuName . "index"}++;
				}
			}
			$Koteihyou .= "</tr>";
		}
		$strBlankCount = '';
		foreach($arrBlankCount as $keyBlank => $valBlank){
			if($strBlankCount != '')
				$strBlankCount .= ' ';
			$strBlankCount .= $keyBlank.':'.$valBlank;
		}
		$Koteihyou = str_replace("@@blank_count@@", '<div class="blank_count">'.$strBlankCount.'</div>', $Koteihyou);

	}
}

$date = new DateTime($SenyuStartDate);
for ($i = 0; $i < $SenyuDateCnt; $i++) {
	$SenyuDate = $date->format('Y-m-d');
	$NextBlankTime = [];
	$NextBlankContinusCount = [];

	$week_str = $week[$date->format('w')];
	if($week_str == '土')
		$week_str = '<span style="color:#0070c0">'.$week_str.'</span>';
	else if($week_str == '日')
		$week_str = '<span style="color:#ff9999">'.$week_str.'</span>';

	if ($KojiHoliday[$i]) { #★１休工日なら
		if ($holiday[$i]) { //土日祝なら
			$Koteihyou .= "<tr class='trtop trholiday' id='row".$SenyuDate."'><td class='ex_table2' style='background-color:pink;vertical-align:top'><span class='senyu_date'>" . $SenyuDate . "</span></td>";
			$Koteihyou .= "<td  class='ex_table2' style='background-color:pink;vertical-align:top'>" . $week_str . "</td>";
			$Koteihyou .= "<td  class='ex_table2' style='background-color:pink;'></td>";
		} else { //平日なら
			$Koteihyou .= "<tr class='trtop trholiday' id='row".$SenyuDate."'><td class='ex_table2'><span class='senyu_date' style='vertical-align:top'>" . $SenyuDate . "</span></td>";
			$Koteihyou .= "<td class='ex_table2' style='vertical-align:top'>" . $week_str . "</td>";
			$Koteihyou .= "<td class='ex_table2'></td>";
		}
		$Koteihyou .= "<td colspan=" . $wWakuColSum . " class='ex_table2'>";
		$Koteihyou .= "休工日</td>";
	} else { #★１休工日でない場合
		if ($holiday[$i]) { //土日祝なら
			$Koteihyou .= "<tr class='trtop' id='row".$SenyuDate."'><td rowspan=" . $rowCountforDay . " class='ex_table2' style='background-color:pink;vertical-align:top'><span class='senyu_date'>" . $SenyuDate . "</span>@@blank_count@@</td>";
			$Koteihyou .= "<td rowspan=" . $rowCountforDay . " class='ex_table2' style='background-color:pink;vertical-align:top'>" . $week_str . "</td>";
		} else { //平日なら
			$Koteihyou .= "<tr class='trtop' id='row".$SenyuDate."'><td rowspan=" . $rowCountforDay . " class='ex_table2' style='vertical-align:top'><span class='senyu_date'>" . $SenyuDate . "</span>@@blank_count@@</td>";
			$Koteihyou .= "<td rowspan=" . $rowCountforDay . " class='ex_table2' style='vertical-align:top'>" . $week_str . "</td>";
		}
		$banNo = 1;
		$abanNo = $banNo;
		$banRowspan = floor($rowCountforDay / $wHansu);
		$arrBlankCount = [];

		for ($j = 0; $j < $rowCountforDay; $j++) {
			if ($j != 0)
				$Koteihyou .= "<tr>";

			if($j % $banRowspan == 0){
				if ($holiday[$i]) { //土日祝なら
					$Koteihyou .= "<td rowspan=" . $banRowspan . " class='ex_table2' style='background-color:pink;vertical-align:top'>" . $banNo . "</td>";
				} else { //平日なら
					$Koteihyou .= "<td rowspan=" . $banRowspan . " class='ex_table2' style='vertical-align:top'>" . $banNo . "</td>";
				}
				$abanNo = $banNo;
				$banNo ++;
			}
	
			for ($k = 0; $k < count($WAKUPATTERN[$wWakuPattern]['AMPM']); $k++) {
				$WakuEndtime   = date('H:i', strtotime($WAKUPATTERN[$wWakuPattern]['EndTime'][$k]));

				$WakuName = $WAKUPATTERN[$wWakuPattern]['AMPM'][$k];
				if(!isset($arrBlankCount[$WakuName]))
					$arrBlankCount[$WakuName] = 0;
				$WakuStart = $WAKUPATTERN[$wWakuPattern]['StartTime'][$k];
				if(!isset($NextBlankTime[$WakuName])){
					$NextBlankTime[$WakuName] = date('H:i', strtotime($WakuStart));
				}
				if(!isset($NextBlankContinusCount[$WakuName])){
					$NextBlankContinusCount[$WakuName] = 1;
				}

				for ($l = 0; $l < ${'wWaku' . $WakuName . 'Col'}; $l++) {
					$ViewOrderNo = $l + 1 + $j * ${'wWaku' . $WakuName . 'Col'};
					$Koteihyou_event = "";

					if ($k % 2 == 0) {
						$Koteihyou_temp = "<td class='link_cell' style='background-color:#ffff9e;' @event@>";
					} else {
						$Koteihyou_temp = "<td class='link_cell' style='background-color:#ffffcf;' @event@>";
					}
					if (!${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}]) {
						$Koteihyou_temp = "<td class='link_cell link_cell_none no-action' style='background-color:#d3d3d3; cursor:default'>";
					}

					if (${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}] == "休工") {
						$Koteihyou_temp = "<td class='link_cell link_cell_none no-action' style='background-color:#d3d3d3; cursor:default'>休工";
						$Koteihyou_event = "";
					} else if (isSlotLabelAki(${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}])) {
						if ($k % 2 == 0) {
							$Koteihyou_temp = "<td class='link_cell_blank' style='background-color:#ffff9e;' @event@>";
						} else {
							$Koteihyou_temp = "<td class='link_cell_blank' style='background-color:#ffffcf;' @event@>";
						}

						$Koteihyou_temp .= ${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}];
						$Koteihyou_event = "onclick=\"clickBtn7('".$SenyuDate."', '".$NextBlankTime[$WakuName]."', '".$WakuName."', '".$abanNo."', '".$ViewOrderNo."', 'aki')\"";

						$arrBlankCount[$WakuName] ++;
						$NextBlankTime[$WakuName] = date('H:i', strtotime("+".(floor($NextBlankContinusCount[$WakuName] / $arrCountRepeat[$k])*$MinuteTime)." minutes", strtotime($NextBlankTime[$WakuName])));
						if($NextBlankTime[$WakuName] > $WakuEndtime)
							$NextBlankTime[$WakuName] = $WakuEndtime;

						$NextBlankContinusCount[$WakuName] ++;
						if($NextBlankContinusCount[$WakuName] > $arrCountRepeat[$k]){
							$NextBlankContinusCount[$WakuName] = 1;
						}
					}else if (isSlotLabelWakuover(${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}])) {
						if ($k % 2 == 0) {
							$Koteihyou_temp = "<td class='link_cell_blank' style='background-color:#ffff9e; color:#f94a4a' @event@>";
						} else {
							$Koteihyou_temp = "<td class='link_cell_blank' style='background-color:#ffffcf; color:#f94a4a' @event@>";
						}

						$Koteihyou_temp .= ${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}];
						$Koteihyou_event = "onclick=\"clickBtn7('".$SenyuDate."', '".$NextBlankTime[$WakuName]."', '".$WakuName."', '".$abanNo."', '".$ViewOrderNo."', 'wakuover')\"";

						$NextBlankTime[$WakuName] = date('H:i', strtotime("+".(floor($NextBlankContinusCount[$WakuName] / $arrCountRepeat[$k])*$MinuteTime)." minutes", strtotime($NextBlankTime[$WakuName])));
						if($NextBlankTime[$WakuName] > $WakuEndtime)
							$NextBlankTime[$WakuName] = $WakuEndtime;

						$NextBlankContinusCount[$WakuName] ++;
						if($NextBlankContinusCount[$WakuName] > $arrCountRepeat[$k]){
							$NextBlankContinusCount[$WakuName] = 1;
						}
					}else if(${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}]) {
						$tID = ${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}];
						$disRoom =$tID;
						$disTooltipRoom =$tID;
						$link_color = "";
						if (strpos($tID, 'overflow@') !== false) {
							$disRoom = '<span style="color:#f94a4a">'.str_replace('overflow@', '', $tID).'</span>';
							$disTooltipRoom = str_replace('overflow@', '', $tID);
							$link_color = "color:#f94a4a";
						}

						if ($k % 2 == 0) {
							$Koteihyou_temp = "<td id='room_".$disTooltipRoom."' class='link_cell' style='background-color:#ffff9e;' @event@>";
						} else {
							$Koteihyou_temp = "<td id='room_".$disTooltipRoom."' class='link_cell' style='background-color:#ffffcf;' @event@>";
						}

						$aLastName = $UserData['LastName'][$disTooltipRoom] ;
						$aTEL = $UserData['TEL'][$disTooltipRoom] ;
						$aEMail = $UserData['EMail'][$disTooltipRoom] ;
						$aMemo = $UserData['Memo'][$disTooltipRoom] ;
						$ReplyFlg = $UserData['ReplyFlg'][$disTooltipRoom] ;
						$ConfirmFlg = $UserData['ConfirmFlg'][$disTooltipRoom] ;
						$aTimeExactHour = $TimeExactHour[$disTooltipRoom];
						$aTimeExactMinutes = $TimeExactMinutes[$disTooltipRoom];
						if($aTimeExactHour || $aTimeExactMinutes)
							$aTimeExact = $aTimeExactHour.":".$aTimeExactMinutes;
						else
							$aTimeExact = null;
						$aTimeMeaning = $TimeMeaning[$disTooltipRoom];
						if($aTimeExact){
							$Koteihyou_temp .= '<div class="multi_val tooltip-container">';
								$Koteihyou_temp .= '<font class="haslink" style="font-size:20px; text-decoration:underline;' . $link_color . '"> <b>' . $disRoom . '</b></font>';
								$Koteihyou_temp .= '<div class="exact_time">'.$aTimeExact.'</div>';
								$Koteihyou_temp .= '<div class="tooltip-text">';
									if($ReplyFlg == '3')
										$Koteihyou_temp .= '<span class="decline">「辞退」</span> <br>';
									else
										$Koteihyou_temp .= '<span class="confirmed">「確定」</span> <br>';
									$Koteihyou_temp .= '<span class="lb">部屋番号:</span> '.$disTooltipRoom.'<br>';
									$Koteihyou_temp .= '<span class="lb">名前:</span> '.$aLastName.'<br>';
									$Koteihyou_temp .= '<span class="lb">連絡先:</span> '.$aTEL.'<br>';
									$Koteihyou_temp .= '<span class="lb">メールアドレス:</span> '.$aEMail.'<br>';
									$Koteihyou_temp .= '<span class="lb">時間指定:</span> '.$aTimeExact.' '.$aTimeMeaning.'<br>';
									$Koteihyou_temp .= '<span class="lb">備考:</span> '.nl2br($aMemo).'<br>';
								$Koteihyou_temp .= '</div>';
							$Koteihyou_temp .= '</div>';

						}else if($ReplyFlg || $ConfirmFlg){
							$Koteihyou_temp .= '<font class="haslink tooltip-container" style="font-size:20px; text-decoration:underline;' . $link_color . '"> <b>' . $disRoom . '</b>';
								$Koteihyou_temp .= '<div class="tooltip-text">';
									if($ReplyFlg == '3')
										$Koteihyou_temp .= '<span class="decline">「辞退」</span> <br>';
									else
										$Koteihyou_temp .= '<span class="confirmed">「確定」</span> <br>';
									$Koteihyou_temp .= '<span class="lb">部屋番号:</span> '.$disTooltipRoom.'<br>';
									$Koteihyou_temp .= '<span class="lb">名前:</span> '.$aLastName.'<br>';
									$Koteihyou_temp .= '<span class="lb">連絡先:</span> '.$aTEL.'<br>';
									$Koteihyou_temp .= '<span class="lb">メールアドレス:</span> '.$aEMail.'<br>';
									$Koteihyou_temp .= '<span class="lb">時間指定:</span> '.$aTimeExact.' '.$aTimeMeaning.'<br>';
									$Koteihyou_temp .= '<span class="lb">備考:</span> '.nl2br($aMemo).'<br>';
								$Koteihyou_temp .= '</div>';
							$Koteihyou_temp .= '</font>';
						
						}else{
							$Koteihyou_temp .= '<font class="tooltip-container" style="font-size:20px"> <b>' . $disRoom . '</b>';
								$Koteihyou_temp .= '<div class="tooltip-text">';
									$Koteihyou_temp .= '<span class="temporary">「仮日程」</span> <br>';
									$Koteihyou_temp .= '<span class="lb">部屋番号:</span> '.$disTooltipRoom.'<br>';
								$Koteihyou_temp .= '</div>';
							$Koteihyou_temp .= '</font>';
						}
						$NextBlankTime[$WakuName] = isset($arrTimeFrom[$disTooltipRoom])?$arrTimeFrom[$disTooltipRoom]:$WakuStart;
						$NextBlankTime[$WakuName] = date('H:i', strtotime($NextBlankTime[$WakuName]));
						if($NextBlankTime[$WakuName] > $WakuEndtime)
							$NextBlankTime[$WakuName] = $WakuEndtime;

						$Koteihyou_event = "onclick=\"clickBtn8('".$disTooltipRoom."' ,'".$aLastName."'  ,'".$aTEL."','".$aMemo."' , '".$SenyuDate."', '".$NextBlankTime[$WakuName]."', '".$WakuName."', '".$aTimeExactHour."', '".$aTimeExactMinutes."', '".$aTimeMeaning."', '".$abanNo."', '".$ViewOrderNo."', '".$ReplyFlg."', '".$ConfirmFlg."','".$aEMail."' )\"";
						$NextBlankTime[$WakuName] = date('H:i', strtotime("+$MinuteTime minutes", strtotime($NextBlankTime[$WakuName])));
						if($NextBlankTime[$WakuName] > $WakuEndtime)
							$NextBlankTime[$WakuName] = $WakuEndtime;
						$NextBlankContinusCount[$WakuName] = 1;
					}
					// $KoteihyouEX[] = $tID;

					// echo "<br>" . $WakuName . ":" . ${$WakuName . "index"};
					$Koteihyou_temp = str_replace("@event@", $Koteihyou_event, $Koteihyou_temp);
					$Koteihyou .= $Koteihyou_temp;

					$Koteihyou .= "</td>";
					${$WakuName . "index"}++;
				}
			}
			$Koteihyou .= "</tr>";
		}
		$strBlankCount = '';
		foreach($arrBlankCount as $keyBlank => $valBlank){
			if($strBlankCount != '')
				$strBlankCount .= ' ';
			$strBlankCount .= $keyBlank.':'.$valBlank;
		}
		$Koteihyou = str_replace("@@blank_count@@", '<div class="blank_count">'.$strBlankCount.'</div>', $Koteihyou);

	}#休工日

	$date->modify('+1 days');
}

foreach($afterReserveDay as $key => $aReserveDay){
	$date = new DateTime($aReserveDay);
	$SenyuDate = $date->format('Y-m-d');
	$NextBlankTime = [];
	$NextBlankContinusCount = [];

	$week_str = $week[$date->format('w')];
	if($week_str == '土')
		$week_str = '<span style="color:#0070c0">'.$week_str.'</span>';
	else if($week_str == '日')
		$week_str = '<span style="color:#ff9999">'.$week_str.'</span>';

	if ($afterKojiHoliday[$key]) { #★１休工日なら
		if ($afterHoliday[$key]) { //土日祝なら
			$Koteihyou .= "<tr class='trtop trreserveday' id='row".$SenyuDate."'><td class='ex_table2' style='vertical-align:top'><span class='senyu_date'>" . $SenyuDate . "</span><div class='reserve_day'>予備日</div></td>";
			$Koteihyou .= "<td  class='ex_table2' style='vertical-align:top'>" . $week_str . "</td>";
			$Koteihyou .= "<td  class='ex_table2'></td>";
		} else { //平日なら
			$Koteihyou .= "<tr class='trtop trreserveday' id='row".$SenyuDate."'><td class='ex_table2' style='vertical-align:top'><span class='senyu_date'>" . $SenyuDate . "</span><div class='reserve_day'>予備日</div></td>";
			$Koteihyou .= "<td class='ex_table2' style='vertical-align:top'>" . $week_str . "</td>";
			$Koteihyou .= "<td class='ex_table2'></td>";
		}
		$Koteihyou .= "<td colspan=" . $wWakuColSum . " class='ex_table2'>";
		$Koteihyou .= "休工日</td>";
	} else { #★１休工日でない場合
		if ($afterHoliday[$key]) { //土日祝なら
			$Koteihyou .= "<tr class='trtop trreserveday' id='row".$SenyuDate."'><td rowspan=" . $rowCountforDay . " class='ex_table2' style='vertical-align:top'><span class='senyu_date'>" . $SenyuDate . "</span><div class='reserve_day'>予備日</div>@@blank_count@@</td>";
			$Koteihyou .= "<td rowspan=" . $rowCountforDay . " class='ex_table2' style='vertical-align:top'>" . $week_str . "</td>";
		} else { //平日なら
			$Koteihyou .= "<tr class='trtop trreserveday' id='row".$SenyuDate."'><td rowspan=" . $rowCountforDay . " class='ex_table2' style='vertical-align:top'><span class='senyu_date'>" . $SenyuDate . "</span><div class='reserve_day'>予備日</div>@@blank_count@@</td>";
			$Koteihyou .= "<td rowspan=" . $rowCountforDay . " class='ex_table2' style='vertical-align:top'>" . $week_str . "</td>";
		}
		$banNo = 1;
		$abanNo = $banNo;
		$banRowspan = floor($rowCountforDay / $wHansu);
		$arrBlankCount = [];

		for ($j = 0; $j < $rowCountforDay; $j++) {
			if ($j != 0)
				$Koteihyou .= "<tr class='trreserveday'>";

			if($j % $banRowspan == 0){
				if ($afterHoliday[$key]) { //土日祝なら
					$Koteihyou .= "<td rowspan=" . $banRowspan . " class='ex_table2' style='vertical-align:top'>" . $banNo . "</td>";
				} else { //平日なら
					$Koteihyou .= "<td rowspan=" . $banRowspan . " class='ex_table2' style='vertical-align:top'>" . $banNo . "</td>";
				}
				$abanNo = $banNo;
				$banNo ++;
			}
	
			for ($k = 0; $k < count($WAKUPATTERN[$wWakuPattern]['AMPM']); $k++) {
				$WakuEndtime   = date('H:i', strtotime($WAKUPATTERN[$wWakuPattern]['EndTime'][$k]));

				$WakuName = $WAKUPATTERN[$wWakuPattern]['AMPM'][$k];
				if(!isset($arrBlankCount[$WakuName]))
					$arrBlankCount[$WakuName] = 0;
				$WakuStart = $WAKUPATTERN[$wWakuPattern]['StartTime'][$k];
				if(!isset($NextBlankTime[$WakuName])){
					$NextBlankTime[$WakuName] = date('H:i', strtotime($WakuStart));
				}
				if(!isset($NextBlankContinusCount[$WakuName])){
					$NextBlankContinusCount[$WakuName] = 1;
				}
				for ($l = 0; $l < ${'wWaku' . $WakuName . 'Col'}; $l++) {
					$ViewOrderNo = $l + 1 + $j * ${'wWaku' . $WakuName . 'Col'};
					$Koteihyou_event = "";

					if ($k % 2 == 0) {
						$Koteihyou_temp = "<td class='link_cell' style='background-color:#ffff9e;' @event@>";
					} else {
						$Koteihyou_temp = "<td class='link_cell' style='background-color:#ffffcf;' @event@>";
					}
					if (!${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}]) {
						$Koteihyou_temp = "<td class='link_cell link_cell_none no-action' style='background-color:#d3d3d3; cursor:default'>";
					}

					if (${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}] == "休工") {
						$Koteihyou_temp = "<td class='link_cell link_cell_none no-action' style='background-color:#d3d3d3; cursor:default'>休工";
						$Koteihyou_event = "";
					} else if (isSlotLabelAki(${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}])) {
						if ($k % 2 == 0) {
							$Koteihyou_temp = "<td class='link_cell_blank' style='background-color:#ffff9e;' @event@>";
						} else {
							$Koteihyou_temp = "<td class='link_cell_blank' style='background-color:#ffffcf;' @event@>";
						}

						$Koteihyou_temp .= ${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}];
						$Koteihyou_event = "onclick=\"clickBtn7('".$SenyuDate."', '".$NextBlankTime[$WakuName]."', '".$WakuName."', '".$abanNo."', '".$ViewOrderNo."', 'aki')\"";

						$arrBlankCount[$WakuName] ++;
						$NextBlankTime[$WakuName] = date('H:i', strtotime("+".(floor($NextBlankContinusCount[$WakuName] / $arrCountRepeat[$k])*$MinuteTime)." minutes", strtotime($NextBlankTime[$WakuName])));
						if($NextBlankTime[$WakuName] > $WakuEndtime)
							$NextBlankTime[$WakuName] = $WakuEndtime;
						$NextBlankContinusCount[$WakuName] ++;
						if($NextBlankContinusCount[$WakuName] > $arrCountRepeat[$k]){
							$NextBlankContinusCount[$WakuName] = 1;
						}
					}else if (isSlotLabelWakuover(${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}])) {
						if ($k % 2 == 0) {
							$Koteihyou_temp = "<td class='link_cell_blank' style='background-color:#ffff9e; color:#f94a4a' @event@>";
						} else {
							$Koteihyou_temp = "<td class='link_cell_blank' style='background-color:#ffffcf; color:#f94a4a' @event@>";
						}

						$Koteihyou_temp .= ${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}];
						$Koteihyou_event = "onclick=\"clickBtn7('".$SenyuDate."', '".$NextBlankTime[$WakuName]."', '".$WakuName."', '".$abanNo."', '".$ViewOrderNo."', 'wakuover')\"";
						$NextBlankTime[$WakuName] = date('H:i', strtotime("+".(floor($NextBlankContinusCount[$WakuName] / $arrCountRepeat[$k])*$MinuteTime)." minutes", strtotime($NextBlankTime[$WakuName])));
						if($NextBlankTime[$WakuName] > $WakuEndtime)
							$NextBlankTime[$WakuName] = $WakuEndtime;
						$NextBlankContinusCount[$WakuName] ++;
						if($NextBlankContinusCount[$WakuName] > $arrCountRepeat[$k]){
							$NextBlankContinusCount[$WakuName] = 1;
						}
					}else if(${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}]) {
						$tID = ${'Waku' . $WakuName . 'Room'}[${$WakuName . "index"}];
						$disRoom =$tID;
						$disTooltipRoom =$tID;
						$link_color = "";
						if (strpos($tID, 'overflow@') !== false) {
							$disRoom = '<span style="color:#f94a4a">'.str_replace('overflow@', '', $tID).'</span>';
							$disTooltipRoom = str_replace('overflow@', '', $tID);
							$link_color = "color:#f94a4a";
						}

						if ($k % 2 == 0) {
							$Koteihyou_temp = "<td id='room_".$disTooltipRoom."' class='link_cell' style='background-color:#ffff9e;' @event@>";
						} else {
							$Koteihyou_temp = "<td id='room_".$disTooltipRoom."' class='link_cell' style='background-color:#ffffcf;' @event@>";
						}


						$aLastName = $UserData['LastName'][$disTooltipRoom] ;
						$aTEL = $UserData['TEL'][$disTooltipRoom] ;
						$aEMail = $UserData['EMail'][$disTooltipRoom] ;
						$aMemo = $UserData['Memo'][$disTooltipRoom] ;
						$ReplyFlg = $UserData['ReplyFlg'][$disTooltipRoom] ;
						$ConfirmFlg = $UserData['ConfirmFlg'][$disTooltipRoom] ;
						$aTimeExactHour = $TimeExactHour[$disTooltipRoom];
						$aTimeExactMinutes = $TimeExactMinutes[$disTooltipRoom];
						if($aTimeExactHour || $aTimeExactMinutes)
							$aTimeExact = $aTimeExactHour.":".$aTimeExactMinutes;
						else
							$aTimeExact = null;
						$aTimeMeaning = $TimeMeaning[$disTooltipRoom];
						if($aTimeExact){
							$Koteihyou_temp .= '<div class="multi_val tooltip-container">';
								$Koteihyou_temp .= '<font class="haslink" style="font-size:20px; text-decoration:underline;'. $link_color .'"> <b>' . $disRoom . '</b></font>';
								$Koteihyou_temp .= '<div class="exact_time">'.$aTimeExact.'</div>';
								$Koteihyou_temp .= '<div class="tooltip-text">';
									if($ReplyFlg == '3')
										$Koteihyou_temp .= '<span class="decline">「辞退」</span> <br>';
									else
										$Koteihyou_temp .= '<span class="confirmed">「確定」</span> <br>';
									$Koteihyou_temp .= '<span class="lb">部屋番号:</span> '.$disTooltipRoom.'<br>';
									$Koteihyou_temp .= '<span class="lb">名前:</span> '.$aLastName.'<br>';
									$Koteihyou_temp .= '<span class="lb">連絡先:</span> '.$aTEL.'<br>';
									$Koteihyou_temp .= '<span class="lb">メールアドレス:</span> '.$aEMail.'<br>';
									$Koteihyou_temp .= '<span class="lb">時間指定:</span> '.$aTimeExact.' '.$aTimeMeaning.'<br>';
									$Koteihyou_temp .= '<span class="lb">備考:</span> '.nl2br($aMemo).'<br>';
								$Koteihyou_temp .= '</div>';
							$Koteihyou_temp .= '</div>';

						}else if($ReplyFlg || $ConfirmFlg){
							$Koteihyou_temp .= '<font class="haslink tooltip-container" style="font-size:20px; text-decoration:underline;' . $link_color . '"> <b>' . $disRoom . '</b>';
								$Koteihyou_temp .= '<div class="tooltip-text">';
									if($ReplyFlg == '3')
										$Koteihyou_temp .= '<span class="decline">「辞退」</span> <br>';
									else
										$Koteihyou_temp .= '<span class="confirmed">「確定」</span> <br>';
									$Koteihyou_temp .= '<span class="lb">部屋番号:</span> '.$disTooltipRoom.'<br>';
									$Koteihyou_temp .= '<span class="lb">名前:</span> '.$aLastName.'<br>';
									$Koteihyou_temp .= '<span class="lb">連絡先:</span> '.$aTEL.'<br>';
									$Koteihyou_temp .= '<span class="lb">メールアドレス:</span> '.$aEMail.'<br>';
									$Koteihyou_temp .= '<span class="lb">時間指定:</span> '.$aTimeExact.' '.$aTimeMeaning.'<br>';
									$Koteihyou_temp .= '<span class="lb">備考:</span> '.nl2br($aMemo).'<br>';
								$Koteihyou_temp .= '</div>';
							$Koteihyou_temp .= '</font>';
						
						}else{
							$Koteihyou_temp .= '<font class="tooltip-container" style="font-size:20px"> <b>' . $disRoom . '</b>';
								$Koteihyou_temp .= '<div class="tooltip-text">';
									$Koteihyou_temp .= '<span class="temporary">「仮日程」</span> <br>';
									$Koteihyou_temp .= '<span class="lb">部屋番号:</span> '.$disTooltipRoom.'<br>';
								$Koteihyou_temp .= '</div>';
							$Koteihyou_temp .= '</font>';
						}
						$NextBlankTime[$WakuName] = isset($arrTimeFrom[$disTooltipRoom])?$arrTimeFrom[$disTooltipRoom]:$WakuStart;
						$NextBlankTime[$WakuName] = date('H:i', strtotime($NextBlankTime[$WakuName]));
						if($NextBlankTime[$WakuName] > $WakuEndtime)
							$NextBlankTime[$WakuName] = $WakuEndtime;
						$Koteihyou_event = "onclick=\"clickBtn8('".$disTooltipRoom."' ,'".$aLastName."'  ,'".$aTEL."','".$aMemo."' , '".$SenyuDate."', '".$NextBlankTime[$WakuName]."', '".$WakuName."', '".$aTimeExactHour."', '".$aTimeExactMinutes."', '".$aTimeMeaning."', '".$abanNo."', '".$ViewOrderNo."', '".$ReplyFlg."', '".$ConfirmFlg."' ,'".$aEMail."' )\"";
						$NextBlankTime[$WakuName] = date('H:i', strtotime("+$MinuteTime minutes", strtotime($NextBlankTime[$WakuName])));
						if($NextBlankTime[$WakuName] > $WakuEndtime)
							$NextBlankTime[$WakuName] = $WakuEndtime;
						$NextBlankContinusCount[$WakuName] = 1;
					}
					// $KoteihyouEX[] = $tID;

					// echo "<br>" . $WakuName . ":" . ${$WakuName . "index"};
					$Koteihyou_temp = str_replace("@event@", $Koteihyou_event, $Koteihyou_temp);
					$Koteihyou .= $Koteihyou_temp;

					$Koteihyou .= "</td>";
					${$WakuName . "index"}++;
				}
			}
			$Koteihyou .= "</tr>";
		}
		$strBlankCount = '';
		foreach($arrBlankCount as $keyBlank => $valBlank){
			if($strBlankCount != '')
				$strBlankCount .= ' ';
			$strBlankCount .= $keyBlank.':'.$valBlank;
		}
		$Koteihyou = str_replace("@@blank_count@@", '<div class="blank_count">'.$strBlankCount.'</div>', $Koteihyou);

	}
}

$Koteihyou .= "</table>";

#######################################移植終わり

	########################################################
	# コンテンツ表示
	########################################################

	$CNT_FILE = "sh_list.tpl";
	$myTemplate = new SPFWTemplate($CNT_FILE, $MyCarrier);
	$HiddenValues = $myTemplate->getValuesToPass();
	$myTemplate->convertTags();
	$myTemplate->outputTemplate();
	unset($myTemplate);
	unset($myLog);

########################################################
# 関数群
########################################################
//最大工事枠数から空きの数を引いた枠数を取得
function getWakuRoomSu($WakuName, $Syoniti, $holiday, $MaxWakuSu, $FirstDateFeature)
{
	// 第一引数：$WakuName string
	//  AM・PMなど

	// 第二引数： $Syoniti boolean
	//  初日かどうか

	// 第三引数：$holiday boolean
	//  土日祝かどうか

	// 第四引数：$MaxWakuSu int
	//  枠ごとの最大工事枠数

	// 第五引数：$FirstDateFeature int
	//  初日考慮
	//  1：午前中NG
	//  2：15時までNG


	//最大工事枠数から空きの数を引く計算をする
	if ($Syoniti == true && $holiday) { //初日・土日祝　(最大工事枠数/2)-1

		$WakuRoomSu = ceil($MaxWakuSu / 2) - 1;#切り上げて1引く。　

		if ($FirstDateFeature == 1 && strpos($WakuName, 'AM') !== FALSE) { //初日午前NG
			$WakuRoomSu = 0;
		} elseif ($FirstDateFeature == 2 && (strpos($WakuName, 'AM') !== FALSE || strpos($WakuName, 'PM1') !== FALSE)) { //初日15：00以降OK
			$WakuRoomSu = 0;
		}
	} elseif ($Syoniti == true) { //初日・平日　最大工事枠数-2

		$WakuRoomSu = $MaxWakuSu - 2;

		if ($FirstDateFeature == 1 && strpos($WakuName, 'AM') !== FALSE) { //初日午前NG
			$WakuRoomSu = 0;
		} elseif ($FirstDateFeature == 2 && (strpos($WakuName, 'AM') !== FALSE || strpos($WakuName, 'PM1') !== FALSE)) { //初日15：00以降OK
			$WakuRoomSu = 0;
		}
	} elseif ($holiday) { //土日祝 最大工事枠数/2
		$WakuRoomSu = ceil($MaxWakuSu / 2);
	} else { //平日 最大工事枠数-1
		$WakuRoomSu = $MaxWakuSu - 1;
	}
	if ($WakuRoomSu < 0) {
		$WakuRoomSu = 0;
	}
	return $WakuRoomSu;
}


?>
